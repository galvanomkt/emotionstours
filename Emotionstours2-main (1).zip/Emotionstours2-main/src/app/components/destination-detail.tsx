import { X, Calendar, DollarSign, Clock, MapPin, Phone, Users, AlertCircle, CreditCard } from 'lucide-react';
import { useState } from 'react';

interface Destination {
  name: string;
  image: string;
  description: string;
  price: string;
  priceOptions?: {
    twoPersons: string;
    threePersons: string;
    fourPersons: string;
  };
  itinerary: string[];
  dates: string[];
  duration: string;
  included: string[];
  generalInfo: string;
}

interface DestinationDetailProps {
  destination: Destination;
  onClose: () => void;
  onReserve: (destName: string) => void;
}

export function DestinationDetail({ destination, onClose, onReserve }: DestinationDetailProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="relative max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-lg bg-white shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 rounded-full bg-white/90 p-2 text-gray-700 transition hover:bg-white"
        >
          <X className="h-6 w-6" />
        </button>
        
        <div className="relative h-64 overflow-hidden">
          <img 
            src={destination.image} 
            alt={destination.name}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
          <div className="absolute bottom-6 left-6">
            <h2 className="mb-2 text-4xl font-bold text-white">{destination.name}</h2>
            <p className="text-lg text-white/90">{destination.description}</p>
          </div>
        </div>

        <div className="p-6">
          {/* Información General */}
          <div className="mb-6 rounded-lg bg-blue-50 p-4">
            <div className="mb-3 flex items-center gap-2">
              <MapPin className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-bold text-gray-900">Información General</h3>
            </div>
            <p className="text-gray-700">{destination.generalInfo}</p>
          </div>

          {/* Detalles del viaje */}
          <div className="mb-6 grid gap-4 md:grid-cols-3">
            <div className="rounded-lg border border-gray-200 p-4">
              <div className="mb-2 flex items-center gap-2 text-green-600">
                <DollarSign className="h-5 w-5" />
                <span className="font-bold">Precio</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{destination.price}</p>
            </div>

            <div className="rounded-lg border border-gray-200 p-4">
              <div className="mb-2 flex items-center gap-2 text-blue-600">
                <Clock className="h-5 w-5" />
                <span className="font-bold">Duración</span>
              </div>
              <p className="text-lg text-gray-900">{destination.duration}</p>
            </div>

            <div className="rounded-lg border border-gray-200 p-4">
              <div className="mb-2 flex items-center gap-2 text-purple-600">
                <Calendar className="h-5 w-5" />
                <span className="font-bold">Fechas</span>
              </div>
              <p className="text-sm text-gray-900">{destination.dates[0]}</p>
            </div>
          </div>

          {/* Opciones de Precio por Persona */}
          {destination.priceOptions && (
            <div className="mb-6">
              <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-gray-900">
                <Users className="h-5 w-5 text-green-600" />
                Opciones de Precio por Persona
              </h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="rounded-lg border-2 border-green-200 bg-green-50 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="font-bold text-gray-900">2 Personas</span>
                    <Users className="h-5 w-5 text-green-600" />
                  </div>
                  <p className="text-2xl font-bold text-green-600">{destination.priceOptions.twoPersons}</p>
                  <p className="mt-1 text-sm text-gray-600">Por persona</p>
                </div>

                <div className="rounded-lg border-2 border-blue-200 bg-blue-50 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="font-bold text-gray-900">3 Personas</span>
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                  <p className="text-2xl font-bold text-blue-600">{destination.priceOptions.threePersons}</p>
                  <p className="mt-1 text-sm text-gray-600">Por persona</p>
                </div>

                <div className="rounded-lg border-2 border-purple-200 bg-purple-50 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="font-bold text-gray-900">4 Personas</span>
                    <Users className="h-5 w-5 text-purple-600" />
                  </div>
                  <p className="text-2xl font-bold text-purple-600">{destination.priceOptions.fourPersons}</p>
                  <p className="mt-1 text-sm text-gray-600">Por persona</p>
                </div>
              </div>
              <div className="mt-4 rounded-lg bg-yellow-50 border border-yellow-200 p-3">
                <p className="text-sm text-gray-700">
                  💰 <strong>Reserva con solo $90</strong> y asegura tu lugar
                </p>
              </div>
            </div>
          )}

          {/* Itinerario */}
          <div className="mb-6">
            <h3 className="mb-3 flex items-center gap-2 text-xl font-bold text-gray-900">
              <Calendar className="h-5 w-5 text-blue-600" />
              Itinerario
            </h3>
            <div className="space-y-3">
              {destination.itinerary.map((item, index) => (
                <div key={index} className="flex gap-3">
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-blue-100 text-sm font-bold text-blue-600">
                    {index + 1}
                  </div>
                  <p className="flex-1 pt-1 text-gray-700">{item}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Incluye */}
          <div className="mb-6">
            <h3 className="mb-3 text-xl font-bold text-gray-900">Lo que incluye</h3>
            <ul className="grid gap-2 md:grid-cols-2">
              {destination.included.map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="mt-1 text-green-600">✓</span>
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Fechas disponibles */}
          <div className="mb-6">
            <h3 className="mb-3 text-xl font-bold text-gray-900">Fechas Disponibles</h3>
            <div className="flex flex-wrap gap-2">
              {destination.dates.map((date, index) => (
                <span 
                  key={index}
                  className="rounded-full bg-gray-100 px-4 py-2 text-sm text-gray-700"
                >
                  {date}
                </span>
              ))}
            </div>
          </div>

          {/* Información especial para Las Vegas */}
          {destination.name === "Las Vegas" && (
            <>
              {/* Recomendaciones */}
              <div className="mb-6 rounded-lg border-2 border-yellow-200 bg-yellow-50 p-5">
                <h3 className="mb-4 flex items-center gap-2 text-xl font-bold text-gray-900">
                  <AlertCircle className="h-5 w-5 text-yellow-600" />
                  Recomendaciones
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span className="mt-1 text-yellow-600">►</span>
                    <span>Se recomienda desayunar antes o llevar lunch y snacks</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 text-yellow-600">►</span>
                    <span>Vestir cómodamente y de acuerdo al clima</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 text-yellow-600">►</span>
                    <span>Visitar sitios web oficiales para consultar mapa, atracciones, shows, actividades y FAQs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 text-yellow-600">►</span>
                    <span>La mejor actitud y ganas de viajar</span>
                  </li>
                </ul>
              </div>

              {/* Métodos de Pago */}
              <div className="mb-6 rounded-lg border-2 border-blue-200 bg-blue-50 p-5">
                <h3 className="mb-4 flex items-center gap-2 text-xl font-bold text-gray-900">
                  <CreditCard className="h-5 w-5 text-blue-600" />
                  Métodos de Pago
                </h3>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="flex items-center gap-2 text-gray-700">
                    <span className="text-blue-600">💵</span>
                    <span>Depósitos</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <span className="text-blue-600">📱</span>
                    <span>Transferencia electrónica</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <span className="text-blue-600">🏦</span>
                    <span>Depósito en banco</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-700">
                    <span className="text-blue-600">💻</span>
                    <span>Pago online</span>
                  </div>
                </div>
                <div className="mt-4 rounded-lg bg-white p-3">
                  <p className="text-sm text-gray-700">
                    <strong>Pago en Oficina de Tijuana:</strong> Efectivo, Tarjeta de débito y/o crédito
                  </p>
                </div>
              </div>

              {/* Nota Importante */}
              <div className="mb-6 rounded-lg border-2 border-red-200 bg-red-50 p-4">
                <h3 className="mb-2 flex items-center gap-2 font-bold text-red-900">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                  NOTA IMPORTANTE
                </h3>
                <ul className="space-y-1 text-sm text-gray-700">
                  <li>• Se requiere visa vigente y permiso I-94</li>
                  <li>• Confirmación de datos de salida y contacto del coordinador se envían un día antes del viaje por la tarde</li>
                  <li>• Liquida 5 días antes del viaje</li>
                </ul>
              </div>
            </>
          )}

          {/* Botón de reserva */}
          <button
            onClick={() => onReserve(destination.name)}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-6 py-4 font-bold text-white transition hover:bg-blue-700"
          >
            <Phone className="h-5 w-5" />
            Reservar Ahora
          </button>
        </div>
      </div>
    </div>
  );
}