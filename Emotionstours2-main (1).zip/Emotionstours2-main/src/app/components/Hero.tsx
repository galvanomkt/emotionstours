import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import { Destination } from '../data';
import { HeroSlide, HeroSettings } from '../hooks/useDestinations';

interface HeroProps {
  onExplore: () => void;
  onSearchSelect: (dest: Destination) => void;
  slides?: HeroSlide[];
  destinations?: Destination[];
  settings?: HeroSettings;
}

const defaultSlides: HeroSlide[] = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1632970055818-b2d80b1b674d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXNuZXklMjBjYXN0bGUlMjBmaXJld29ya3MlMjB0aGVtZSUyMHBhcmt8ZW58MXx8fHwxNzcwNjgxMzk3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Magia en Familia",
    subtitle: "Vive la experiencia Disney"
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1543175547-faf7863981a8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFuZCUyMGNhbnlvbiUyMGxhbmRzY2FwZSUyMG5hdHVyZXxlbnwxfHx8fDE3NzA2ODEzOTd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Naturaleza Pura",
    subtitle: "Explora el Gran Cañón"
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1601056645460-05fd9ad8f4e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXMlMjB2ZWdhcyUyMHN0cmlwJTIwbmlnaHQlMjBjaXR5JTIwbGlnaHRzfGVufDF8fHx8MTc3MDY4MTM5N3ww&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Vida Nocturna",
    subtitle: "Diviértete en Las Vegas"
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1714412192114-61dca8f15f68?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcGFyYWRpc2UlMjB2YWNhdGlvbnxlbnwxfHx8fDE3NzA2MjU1NDF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Relax Total",
    subtitle: "Descubre Mulegé"
  }
];

const defaultSettings: HeroSettings = {
  interval: 6000,
  transitionType: 'fade',
  subtitleText: 'Tu próxima aventura comienza aquí. Descubre los mejores destinos con Emotion Tours.'
};

export const Hero = ({ onExplore, onSearchSelect, slides = defaultSlides, destinations = [], settings = defaultSettings }: HeroProps) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);

  // Ensure slides array is not empty
  const activeSlides = slides.length > 0 ? slides : defaultSlides;

  const filteredDestinations = searchQuery.length > 0 
    ? destinations.filter(dest => 
        (dest.visible !== false) &&
        (dest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        dest.description.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  useEffect(() => {
    const timer = setInterval(() => {
      if (!showResults) { 
        setCurrentSlide((prev) => (prev + 1) % activeSlides.length);
      }
    }, settings.interval);

    return () => clearInterval(timer);
  }, [showResults, activeSlides.length, settings.interval]);

  const changeSlide = (direction: 'next' | 'prev') => {
    if (direction === 'next') {
      setCurrentSlide((prev) => (prev + 1) % activeSlides.length);
    } else {
      setCurrentSlide((prev) => (prev - 1 + activeSlides.length) % activeSlides.length);
    }
  };

  const handleSearchSelect = (dest: Destination) => {
    onSearchSelect(dest);
    setSearchQuery('');
    setShowResults(false);
  };

  const handleExploreClick = () => {
    const currentDestinationId = activeSlides[currentSlide].destinationId;
    if (currentDestinationId) {
      const destination = destinations.find(d => d.id === currentDestinationId);
      if (destination) {
        onSearchSelect(destination);
        return;
      }
    }
    // Fallback if no destination linked or not found
    onExplore();
  };

  return (
    <div className="relative h-[85vh] w-full overflow-hidden group">
      {/* Slides Background - Removed mode="wait" for crossfade */}
      <AnimatePresence>
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, scale: settings.transitionType === 'slide' ? 1 : 1.1, x: settings.transitionType === 'slide' ? 100 : 0 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          exit={{ opacity: 0, x: settings.transitionType === 'slide' ? -100 : 0 }}
          transition={{ duration: 1.5, ease: "easeInOut" }} // Slower duration for smoother crossfade
          className="absolute inset-0"
        >
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url('${activeSlides[currentSlide].image}')` }}
          />
        </motion.div>
      </AnimatePresence>

      {/* Permanent Overlay - Replaces the per-slide gradient to avoid flashing */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-slate-900/90 pointer-events-none z-10" />

      {/* Manual Controls */}
      <div className="absolute inset-0 flex items-center justify-between px-4 sm:px-8 z-30 pointer-events-none">
        <button 
          onClick={(e) => { e.stopPropagation(); changeSlide('prev'); }}
          className="pointer-events-auto p-2 rounded-full bg-white/20 text-white hover:bg-white/40 backdrop-blur-md transition-all transform hover:scale-110 active:scale-95 touch-manipulation"
          aria-label="Previous Slide"
        >
          <ChevronLeft size={32} />
        </button>
        <button 
          onClick={(e) => { e.stopPropagation(); changeSlide('next'); }}
          className="pointer-events-auto p-2 rounded-full bg-white/20 text-white hover:bg-white/40 backdrop-blur-md transition-all transform hover:scale-110 active:scale-95 touch-manipulation"
          aria-label="Next Slide"
        >
          <ChevronRight size={32} />
        </button>
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4 z-20 pointer-events-none">
        
        {/* Static Search Bar - MOVED TO TOP */}
        <div className="relative w-full max-w-md mb-8 group/search pointer-events-auto">
        <div className="relative">
            <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowResults(e.target.value.length > 0);
            }}
            onFocus={() => setShowResults(searchQuery.length > 0)}
            placeholder="¿A dónde quieres ir?"
            className="w-full py-4 pl-12 pr-4 rounded-full bg-white/10 backdrop-blur-md border border-white/30 text-white placeholder-blue-100 focus:outline-none focus:bg-white/20 focus:border-white transition-all shadow-lg text-lg"
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-200" size={24} />
        </div>

        {/* Dropdown Results */}
        <AnimatePresence>
            {showResults && filteredDestinations.length > 0 && (
            <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl overflow-hidden z-50 text-left max-h-60 overflow-y-auto"
            >
                {filteredDestinations.map((dest) => (
                <button
                    key={dest.id}
                    onClick={() => handleSearchSelect(dest)}
                    className="w-full px-6 py-3 hover:bg-blue-50 flex items-center gap-3 transition-colors border-b border-gray-100 last:border-0"
                >
                    <img src={dest.image} alt={dest.name} className="w-10 h-10 rounded-lg object-cover" />
                    <div>
                    <p className="font-bold text-slate-800 text-sm">{dest.name}</p>
                    <p className="text-xs text-slate-500 flex items-center gap-1">
                        <MapPin size={10} /> {dest.duration}
                    </p>
                    </div>
                </button>
                ))}
            </motion.div>
            )}
        </AnimatePresence>
        </div>

        {/* Dynamic Content Container (Title/Subtitle) */}
        <div className="flex flex-col items-center justify-center min-h-[180px] mb-8">
            <AnimatePresence mode="wait">
                <motion.div
                    key={`text-${currentSlide}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.5 }}
                    className="flex flex-col items-center pointer-events-auto"
                >
                <h1 className="text-4xl md:text-7xl font-black text-white mb-6 drop-shadow-2xl tracking-tight">
                    <span className="block text-[#4cc9f0] text-2xl md:text-4xl font-bold mb-2 uppercase tracking-widest">
                    {activeSlides[currentSlide].subtitle}
                    </span>
                    {activeSlides[currentSlide].title}
                </h1>
                
                <p className="text-lg md:text-2xl text-slate-200 mb-2 max-w-2xl mx-auto font-light leading-relaxed drop-shadow-md">
                    {settings.subtitleText}
                </p>
                </motion.div>
            </AnimatePresence>
        </div>

        {/* Button - Static Position but Dynamic Action */}
        <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleExploreClick}
            className="pointer-events-auto bg-[#1c85c5] hover:bg-[#1883c2] text-white text-lg font-bold py-4 px-10 rounded-full transition-all shadow-[0_0_20px_rgba(28,133,197,0.5)] border-2 border-transparent hover:border-white/20"
        >
            Explorar Destino
        </motion.button>

      </div>

      {/* Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3 z-30 pointer-events-auto">
        {activeSlides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-2 rounded-full transition-all duration-300 ${
              idx === currentSlide ? 'w-8 bg-[#1c85c5]' : 'w-2 bg-white/50 hover:bg-white'
            }`}
          />
        ))}
      </div>
    </div>
  );
};