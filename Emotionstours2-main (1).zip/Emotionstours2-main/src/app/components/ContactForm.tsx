
import React from 'react';
import { useForm } from 'react-hook-form';
import { motion } from 'motion/react';
import { Send, Phone, Mail, MapPin, Globe } from 'lucide-react';
import { toast } from 'sonner';
import { Destination } from '../data';

type FormData = {
  name: string;
  email: string;
  phone: string;
  destination: string;
  message: string;
};

interface ContactFormProps {
  initialDestination?: string;
  destinations?: Destination[];
}

export const ContactForm = ({ initialDestination, destinations = [] }: ContactFormProps) => {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    defaultValues: {
      destination: initialDestination || ''
    }
  });

  const onSubmit = (data: FormData) => {
    const subject = `Nuevo contacto de web: ${data.name}`;
    const body = `Hola, me interesa información sobre: ${data.destination}\n\nMis datos son:\nNombre: ${data.name}\nTeléfono: ${data.phone}\nEmail: ${data.email}\n\nMensaje adicional:\n${data.message}`;
    
    // Open mail client
    window.location.href = `mailto:mkt.emotionstours@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    
    toast.success('Abriendo tu correo para enviar el mensaje...');
    reset();
  };

  return (
    <div className="bg-blue-50/50 py-20 px-4 sm:px-6 lg:px-8" id="contact">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight sm:text-5xl">Contáctanos</h2>
          <p className="mt-4 text-xl text-slate-500">Estamos listos para planear tu próxima aventura.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="bg-slate-50 p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-slate-800 mb-6">Información</h3>
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-green-100 p-3 rounded-lg mr-4 text-green-600">
                  {/* WhatsApp Logo */}
                  <img 
                    src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
                    alt="WhatsApp" 
                    className="w-6 h-6 filter brightness-0 saturate-100 invert-[.25] sepia-[.95] saturate-[20] hue-rotate-[100deg]" 
                  />
                </div>
                <div>
                  <p className="font-bold text-slate-800 mb-2">Contáctanos por Whatsapp</p>
                  <div className="flex flex-col gap-2">
                    {['664 760 0861', '664 594 7666', '665 594 7666'].map((num) => (
                      <a 
                        key={num}
                        href={`https://wa.me/52${num.replace(/\s+/g, '')}?text=${encodeURIComponent('Hola quiero información para viajar a....')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-slate-600 hover:text-green-600 font-medium transition-colors flex items-center gap-2"
                      >
                         {num}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-purple-100 p-3 rounded-lg mr-4 text-purple-600">
                  <Mail size={24} />
                </div>
                <div>
                  <p className="font-bold text-slate-800">Email</p>
                  <a href="mailto:mkt.emotionstours@gmail.com" className="text-slate-600 hover:text-blue-600 transition-colors">
                    mkt.emotionstours@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-purple-100 p-3 rounded-lg mr-4 text-purple-600">
                  <MapPin size={24} />
                </div>
                <div>
                  <p className="font-bold text-slate-800">Oficina</p>
                  <p className="text-slate-600">P.º del Centenario 9580-11, Zona Urbana Rio Tijuana, 22010 Tijuana, B.C., México</p>
                  
                  <div className="mt-4 w-full h-40 rounded-lg overflow-hidden border border-slate-200 mb-3 shadow-inner">
                    <iframe 
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3363.669864703534!2d-117.0267205244569!3d32.53612597376518!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80d9484f37471d49%3A0xc640320775836232!2sP.%C2%BA%20del%20Centenario%209580-11%2C%20Zona%20Urbana%20Rio%20Tijuana%2C%2022010%20Tijuana%2C%20B.C.%2C%20Mexico!5e0!3m2!1sen!2sus!4v1708300000000!5m2!1sen!2sus" 
                      width="100%" 
                      height="100%" 
                      style={{ border: 0 }} 
                      allowFullScreen 
                      loading="lazy" 
                      title="Mapa Oficina"
                    />
                  </div>
                  
                  <a 
                    href="https://maps.app.goo.gl/BVwMWdNm2ePvFfaHA"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors gap-2 shadow-sm"
                  >
                     <MapPin size={18} /> Cómo llegar
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-12">
              <p className="text-slate-500 italic">
                "Viajar es la única cosa que compras que te hace más rico."
              </p>
            </div>
          </div>

          {/* Form */}
          <motion.form 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            onSubmit={handleSubmit(onSubmit)} 
            className="space-y-6"
          >
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nombre Completo</label>
              <input 
                {...register('name', { required: true })}
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                placeholder="Juan Pérez"
              />
              {errors.name && <span className="text-red-500 text-xs mt-1">Este campo es requerido</span>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                <input 
                  {...register('email', { required: true, pattern: /^\S+@\S+$/i })}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="juan@ejemplo.com"
                />
                 {errors.email && <span className="text-red-500 text-xs mt-1">Email inválido</span>}
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Teléfono</label>
                <input 
                  {...register('phone', { required: true })}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="(664) 000-0000"
                />
                 {errors.phone && <span className="text-red-500 text-xs mt-1">Requerido</span>}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Destino de Interés</label>
              <select 
                {...register('destination')}
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 outline-none bg-white"
              >
                <option value="">Selecciona un destino...</option>
                {destinations.filter(d => d.visible !== false).map((dest) => (
                  <option key={dest.id} value={dest.name}>{dest.name}</option>
                ))}
                <option value="Otro">Otro</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Mensaje</label>
              <textarea 
                {...register('message')}
                rows={4}
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-purple-500 outline-none"
                placeholder="¿Tienes dudas específicas o fechas en mente?"
              />
            </div>

            <button 
              type="submit"
              className="w-full bg-slate-900 text-white font-bold py-4 rounded-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
            >
              Enviar Mensaje <Send size={18} />
            </button>
          </motion.form>
        </div>
      </div>
    </div>
  );
};
