
import React from 'react';
import { Destination } from '../data';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';

interface CategoriesSectionProps {
  title: string;
  category: string;
  destinations: Destination[];
  onSelect: (destination: Destination) => void;
  id: string;
}

export const CategoriesSection = ({ title, category, destinations, onSelect, id }: CategoriesSectionProps) => {
  const filtered = destinations.filter(d => d.category === category && d.visible !== false);
  const isHighlightCategory = category === 'Parks' || category === 'Tours';

  if (filtered.length === 0) return null;

  return (
    <div id={id} className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-end justify-between mb-12">
        <div>
           <h2 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight uppercase">{title}</h2>
           <div className="h-2 w-24 bg-purple-600 mt-2"></div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map((dest, i) => (
          <motion.div
            key={dest.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="group cursor-pointer"
            onClick={() => onSelect(dest)}
          >
            <div className="relative h-96 overflow-hidden rounded-2xl shadow-lg">
              <div className="absolute inset-0 bg-slate-900/20 group-hover:bg-slate-900/0 transition-colors z-10" />
              <img 
                src={dest.image} 
                alt={dest.name} 
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                style={{ objectPosition: dest.imagePosition || 'center' }}
              />
              
              {isHighlightCategory && (
                <div className="absolute top-4 right-4 bg-[#1c85c5] text-white px-4 py-2 rounded-full font-bold shadow-md z-30 transform group-hover:scale-105 transition-transform">
                  ${dest.pricing[0].price} {dest.pricing[0].currency}
                </div>
              )}

              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent z-20">
                <span className="text-purple-300 font-bold text-sm tracking-wider uppercase mb-1 block">
                  {dest.duration}
                </span>
                <div className="flex justify-between items-end">
                  <h3 className="text-3xl font-black text-white leading-none">
                    {dest.name}
                  </h3>
                  <div className="bg-white/20 backdrop-blur-md p-2 rounded-full text-white group-hover:bg-white group-hover:text-purple-600 transition-colors">
                    <ArrowUpRight size={24} />
                  </div>
                </div>
                {!isHighlightCategory && (
                  <div className="mt-4 flex items-center gap-2 text-white/80 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-4 group-hover:translate-y-0 duration-300">
                    <span>Desde ${dest.pricing[0].price} {dest.pricing[0].currency}</span>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
