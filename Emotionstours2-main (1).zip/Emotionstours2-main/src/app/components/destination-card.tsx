import { MapPin } from 'lucide-react';

interface DestinationCardProps {
  name: string;
  image: string;
  description: string;
  price: string;
  onClick: () => void;
}

export function DestinationCard({ name, image, description, price, onClick }: DestinationCardProps) {
  return (
    <div 
      className="group cursor-pointer overflow-hidden rounded-lg bg-white shadow-md transition-all hover:shadow-xl"
      onClick={onClick}
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={image} 
          alt={name}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-3 left-3 right-3">
          <h3 className="text-xl font-bold text-white">{name}</h3>
        </div>
      </div>
      <div className="p-4">
        <p className="mb-3 text-sm text-gray-600 line-clamp-2">{description}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1 text-sm text-blue-600">
            <MapPin className="h-4 w-4" />
            <span>Ver detalles</span>
          </div>
          <span className="font-bold text-green-600">{price}</span>
        </div>
      </div>
    </div>
  );
}
