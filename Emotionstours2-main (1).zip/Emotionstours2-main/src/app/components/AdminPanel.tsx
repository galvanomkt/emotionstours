import React, { useState, useRef, useEffect } from 'react';
import { Destination, Review } from '../data';
import { HeroSlide, HeroSettings } from '../hooks/useDestinations';
import { X, Upload, Save, Plus, Trash2, Loader2, LayoutTemplate, Plane, Users, User, MessageSquare, Clock, Type, Link as LinkIcon, Image as ImageIcon, Check, ChevronLeft, ChevronRight, Grid3X3, Eye, EyeOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

interface AdminPanelProps {
  destinations: Destination[];
  heroSlides: HeroSlide[];
  reviews: Review[];
  whatsappNumber: string;
  heroSettings?: HeroSettings;
  onSave: (dests: Destination[]) => Promise<boolean>;
  onSaveHero: (slides: HeroSlide[]) => Promise<boolean>;
  onSaveReviews: (reviews: Review[]) => Promise<boolean>;
  onSaveSettings: (settings: { whatsappNumber: string, heroSettings?: HeroSettings }) => Promise<boolean>;
  onUpload: (file: File) => Promise<string | null>;
  onFetchMedia: () => Promise<any[]>;
  onClose: () => void;
}

const PositionControl = ({ value, onChange }: { value?: string, onChange: (val: string) => void }) => {
  const positions = [
    { label: '↖', value: 'top left' },
    { label: '↑', value: 'top center' },
    { label: '↗', value: 'top right' },
    { label: '←', value: 'center left' },
    { label: '•', value: 'center center' },
    { label: '→', value: 'center right' },
    { label: '↙', value: 'bottom left' },
    { label: '↓', value: 'bottom center' },
    { label: '↘', value: 'bottom right' },
  ];

  const currentValue = value || 'center center';

  return (
    <div className="bg-white/90 backdrop-blur-sm p-2 rounded-lg shadow-sm border border-slate-200">
      <div className="text-[10px] uppercase font-bold text-slate-400 mb-1 text-center">Posición</div>
      <div className="grid grid-cols-3 gap-1 w-20">
        {positions.map((pos) => (
          <button
            key={pos.value}
            onClick={(e) => { e.stopPropagation(); onChange(pos.value); }}
            className={`w-full aspect-square text-[10px] flex items-center justify-center border rounded transition-colors ${
              currentValue === pos.value ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50 hover:text-slate-800'
            }`}
            title={`Alinear: ${pos.value}`}
          >
            {pos.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export const AdminPanel = ({ 
  destinations: initialDestinations, 
  heroSlides: initialHeroSlides,
  reviews: initialReviews,
  whatsappNumber: initialWhatsapp,
  heroSettings: initialHeroSettings,
  onSave, 
  onSaveHero,
  onSaveReviews,
  onSaveSettings,
  onUpload, 
  onFetchMedia,
  onClose 
}: AdminPanelProps) => {
  const [activeTab, setActiveTab] = useState<'destinations' | 'hero' | 'reviews'>('destinations');
  const [destinations, setDestinations] = useState<Destination[]>(initialDestinations);
  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>(initialHeroSlides || []);
  const [reviews, setReviews] = useState<Review[]>(initialReviews || []);
  const [whatsappNumber, setWhatsappNumber] = useState<string>(initialWhatsapp || '664 760 0861');
  const [heroSettings, setHeroSettings] = useState<HeroSettings>(initialHeroSettings || { interval: 6000, transitionType: 'fade', subtitleText: 'Tu próxima aventura comienza aquí...' });
  const [isSaving, setIsSaving] = useState(false);
  
  // Media Library State
  const [showMediaLibrary, setShowMediaLibrary] = useState(false);
  const [mediaFiles, setMediaFiles] = useState<any[]>([]);
  const [loadingMedia, setLoadingMedia] = useState(false);
  const [targetForMedia, setTargetForMedia] = useState<{
    id: string; 
    type: 'main' | 'gallery' | 'hero' | 'review-avatar' | 'review-image';
  } | null>(null);
  
  const [uploadingState, setUploadingState] = useState<{
    id: string; 
    type: 'main' | 'gallery' | 'hero' | 'review-avatar' | 'review-image';
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = async () => {
    setIsSaving(true);
    if (activeTab === 'destinations') {
      await onSave(destinations);
    } else if (activeTab === 'hero') {
      await Promise.all([
        onSaveHero(heroSlides),
        onSaveSettings({ whatsappNumber, heroSettings })
      ]);
    } else {
      await onSaveReviews(reviews);
    }
    setIsSaving(false);
  };

  // --- MEDIA LIBRARY HANDLERS ---
  const openMediaLibrary = async (id: string, type: 'main' | 'gallery' | 'hero' | 'review-avatar' | 'review-image') => {
    setTargetForMedia({ id, type });
    setShowMediaLibrary(true);
    setLoadingMedia(true);
    const files = await onFetchMedia();
    setMediaFiles(files);
    setLoadingMedia(false);
  };

  const selectMedia = (url: string) => {
    if (!targetForMedia) return;
    const { id, type } = targetForMedia;

    if (type === 'hero') {
      const slideId = parseInt(id);
      setHeroSlides(prev => prev.map(s => s.id === slideId ? { ...s, image: url } : s));
    } else if (type === 'review-avatar') {
      setReviews(prev => prev.map(r => r.id === id ? { ...r, avatar: url } : r));
    } else if (type === 'review-image') {
      setReviews(prev => prev.map(r => r.id === id ? { ...r, image: url } : r));
    } else {
      setDestinations(prev => prev.map(dest => {
        if (dest.id !== id) return dest;
        if (type === 'main') {
          return { ...dest, image: url };
        } else {
          // Avoid duplicates in gallery
          const currentGallery = dest.gallery || [];
          if (currentGallery.includes(url)) return dest;
          return { ...dest, gallery: [...currentGallery, url] };
        }
      }));
    }
    
    setShowMediaLibrary(false);
    setTargetForMedia(null);
    toast.success('Imagen seleccionada');
  };

  // --- DESTINATION HANDLERS ---
  const handleUpdateDest = (id: string, field: keyof Destination, value: any) => {
    setDestinations(prev => prev.map(d => d.id === id ? { ...d, [field]: value } : d));
  };

  // Check if destination uses multi-person pricing (rooms)
  const isMultiPricing = (dest: Destination) => {
    return dest.pricing && dest.pricing.some(p => p.people > 1);
  };

  const togglePricingType = (destId: string, type: 'single' | 'room') => {
    setDestinations(prev => prev.map(d => {
      if (d.id !== destId) return d;
      
      const currentCurrency = d.pricing?.[0]?.currency || 'USD';
      
      if (type === 'single') {
        // Switch to single price per person
        return {
          ...d,
          pricing: [{ people: 1, price: 0, currency: currentCurrency }]
        };
      } else {
        // Switch to room pricing (Quad, Triple, Double)
        return {
          ...d,
          pricing: [
            { people: 4, price: 0, currency: currentCurrency }, // Cuadruple
            { people: 3, price: 0, currency: currentCurrency }, // Triple
            { people: 2, price: 0, currency: currentCurrency }  // Doble
          ]
        };
      }
    }));
  };

  const updatePriceValue = (destId: string, peopleCount: number, price: number) => {
    setDestinations(prev => prev.map(d => {
      if (d.id !== destId) return d;
      
      const newPricing = [...(d.pricing || [])];
      const index = newPricing.findIndex(p => p.people === peopleCount);
      
      if (index >= 0) {
        newPricing[index] = { ...newPricing[index], price };
      } else {
        // Should not happen if initialized correctly, but safe fallback
        newPricing.push({ people: peopleCount, price, currency: d.pricing?.[0]?.currency || 'USD' });
      }
      
      // Sort to keep order consistent (4, 3, 2, 1)
      newPricing.sort((a, b) => b.people - a.people);
      
      return { ...d, pricing: newPricing };
    }));
  };

  const updateCurrency = (destId: string, currency: 'USD' | 'MXN') => {
    setDestinations(prev => prev.map(d => {
      if (d.id !== destId) return d;
      const newPricing = d.pricing?.map(p => ({ ...p, currency })) || [];
      return { ...d, pricing: newPricing };
    }));
  };

  const getPriceByPeople = (dest: Destination, people: number) => {
    return dest.pricing?.find(p => p.people === people)?.price || 0;
  };

  // --- HERO HANDLERS ---
  const handleUpdateHero = (id: number, field: keyof HeroSlide, value: any) => {
    setHeroSlides(prev => prev.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const updateHeroSettings = (field: keyof HeroSettings, value: any) => {
    setHeroSettings(prev => ({ ...prev, [field]: value }));
  };

  // --- REVIEW HANDLERS ---
  const handleUpdateReview = (id: string, field: keyof Review, value: any) => {
    setReviews(prev => prev.map(r => r.id === id ? { ...r, [field]: value } : r));
  };

  const addNewReview = () => {
    const newReview: Review = {
      id: `new-${Date.now()}`,
      name: 'Nuevo Cliente',
      date: 'Hace 1 día',
      rating: 5,
      text: '¡Excelente experiencia! Totalmente recomendado.',
      avatar: 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=150',
    };
    setReviews([newReview, ...reviews]);
    toast.info('Nueva reseña creada.');
  };

  const removeReview = (id: string) => {
    if (confirm('¿Estás seguro de eliminar esta reseña?')) {
      setReviews(prev => prev.filter(r => r.id !== id));
    }
  };

  // --- SHARED UPLOAD HANDLER ---
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !uploadingState) return;

    const { id, type } = uploadingState;
    const fileList = Array.from(files);
    const loadingToast = toast.loading(`Subiendo ${fileList.length} imagen(es)...`);

    try {
      const uploadPromises = fileList.map(file => onUpload(file));
      const urls = await Promise.all(uploadPromises);
      const validUrls = urls.filter((url): url is string => url !== null);

      if (validUrls.length > 0) {
        if (type === 'hero') {
          const slideId = parseInt(id);
          setHeroSlides(prev => prev.map(s => s.id === slideId ? { ...s, image: validUrls[0] } : s));
        } else if (type === 'review-avatar') {
          setReviews(prev => prev.map(r => r.id === id ? { ...r, avatar: validUrls[0] } : r));
        } else if (type === 'review-image') {
          setReviews(prev => prev.map(r => r.id === id ? { ...r, image: validUrls[0] } : r));
        } else {
          setDestinations(prev => prev.map(dest => {
            if (dest.id !== id) return dest;
            if (type === 'main') {
              return { ...dest, image: validUrls[0] };
            } else {
              const newGallery = dest.gallery ? [...dest.gallery, ...validUrls] : validUrls;
              return { ...dest, gallery: newGallery };
            }
          }));
        }
        toast.success('Imágenes actualizadas', { id: loadingToast });
      } else {
        toast.error('No se pudieron subir las imágenes', { id: loadingToast });
      }
    } catch (error) {
      console.error(error);
      toast.error('Error durante la subida', { id: loadingToast });
    }
    
    setUploadingState(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const triggerUpload = (id: string, type: 'main' | 'gallery' | 'hero' | 'review-avatar' | 'review-image') => {
    setUploadingState({ id, type });
    if (fileInputRef.current) {
        if (type === 'gallery') {
            fileInputRef.current.setAttribute('multiple', 'true');
        } else {
            fileInputRef.current.removeAttribute('multiple');
        }
        fileInputRef.current.click();
    }
  };

  const removeGalleryImage = (destId: string, imgUrl: string) => {
    if (!confirm('¿Borrar esta imagen de la galería?')) return;
    setDestinations(prev => prev.map(d => {
      if (d.id !== destId) return d;
      return { ...d, gallery: d.gallery?.filter(url => url !== imgUrl) || [] };
    }));
  };

  const moveGalleryImage = (destId: string, index: number, direction: 'left' | 'right') => {
    setDestinations(prev => prev.map(d => {
      if (d.id !== destId || !d.gallery) return d;
      const newGallery = [...d.gallery];
      if (direction === 'left' && index > 0) {
        [newGallery[index - 1], newGallery[index]] = [newGallery[index], newGallery[index - 1]];
      } else if (direction === 'right' && index < newGallery.length - 1) {
        [newGallery[index + 1], newGallery[index]] = [newGallery[index], newGallery[index + 1]];
      }
      return { ...d, gallery: newGallery };
    }));
  };

  const addNewDest = () => {
    const newDest: Destination = {
      id: `new-${Date.now()}`,
      name: 'Nuevo Destino',
      category: 'Tours',
      year: 2026,
      duration: '1 Día',
      image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=1080',
      description: 'Descripción del viaje...',
      dates: ['Próximamente'],
      dateCustomFormat: 'Próximamente',
      pricing: [{ people: 1, price: 0, currency: 'USD' }],
      includes: ['Transporte'],
      gallery: [],
      visible: true
    };
    setDestinations([newDest, ...destinations]);
    toast.info('Nuevo destino creado.');
  };

  const removeDest = (id: string) => {
    if (confirm('¿Estás seguro de eliminar este destino?')) {
      setDestinations(prev => prev.filter(d => d.id !== id));
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept="image/*"
        onChange={handleFileUpload}
      />

      {/* Media Library Modal */}
      <AnimatePresence>
        {showMediaLibrary && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-8 bg-black/80"
          >
            <div className="bg-white rounded-xl w-full max-w-5xl h-[80vh] flex flex-col overflow-hidden relative">
               <div className="p-4 border-b flex justify-between items-center bg-slate-50">
                  <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                    <ImageIcon size={20} /> Galería de Imágenes (Servidor)
                  </h3>
                  <button onClick={() => setShowMediaLibrary(false)} className="p-2 hover:bg-slate-200 rounded-full">
                    <X size={20} />
                  </button>
               </div>
               
               <div className="flex-1 overflow-y-auto p-6 bg-slate-100">
                  {loadingMedia ? (
                    <div className="flex justify-center items-center h-full flex-col gap-4">
                       <Loader2 className="animate-spin text-blue-500" size={40} />
                       <p className="text-slate-500">Cargando imágenes del servidor...</p>
                    </div>
                  ) : mediaFiles.length === 0 ? (
                    <div className="flex justify-center items-center h-full text-slate-400">
                       No hay imágenes en el servidor. Sube una nueva.
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                       {mediaFiles.map((file, idx) => (
                         <div 
                           key={idx} 
                           className="aspect-square bg-white rounded-lg overflow-hidden cursor-pointer hover:ring-4 hover:ring-blue-400 transition-all relative group shadow-sm"
                           onClick={() => selectMedia(file.url)}
                         >
                            <img src={file.url} alt="Media" className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                               <Check className="text-white opacity-0 group-hover:opacity-100 transform scale-0 group-hover:scale-125 transition-all" size={32} />
                            </div>
                         </div>
                       ))}
                    </div>
                  )}
               </div>
               
               <div className="p-4 border-t bg-white flex justify-between items-center text-xs text-slate-500">
                  <span>Selecciona una imagen para usarla en el destino.</span>
                  <span>{mediaFiles.length} imágenes encontradas</span>
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white w-full max-w-6xl max-h-[90vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col"
      >
        <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-slate-50">
          <div className="flex items-center gap-6">
            <div>
              <h2 className="text-2xl font-black text-slate-800">Panel de Administración</h2>
              <p className="text-slate-500 text-sm">Gestiona el contenido de tu web</p>
            </div>
            
            <div className="flex bg-slate-100 p-1 rounded-lg">
              <button
                onClick={() => setActiveTab('destinations')}
                className={`px-4 py-2 rounded-md text-sm font-bold flex items-center gap-2 transition-all ${
                  activeTab === 'destinations' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Plane size={16} /> Viajes
              </button>
              <button
                onClick={() => setActiveTab('hero')}
                className={`px-4 py-2 rounded-md text-sm font-bold flex items-center gap-2 transition-all ${
                  activeTab === 'hero' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <LayoutTemplate size={16} /> Portada
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`px-4 py-2 rounded-md text-sm font-bold flex items-center gap-2 transition-all ${
                  activeTab === 'reviews' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <MessageSquare size={16} /> Reseñas
              </button>
            </div>
          </div>

          <div className="flex gap-3">
            <button 
              onClick={handleSave} 
              disabled={isSaving}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2.5 rounded-full font-bold transition-all disabled:opacity-50"
            >
              {isSaving ? <Loader2 className="animate-spin" /> : <Save size={18} />}
              Guardar {activeTab === 'destinations' ? 'Viajes' : activeTab === 'hero' ? 'Portada' : 'Reseñas'}
            </button>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50">
          
          {activeTab === 'destinations' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <button 
                onClick={addNewDest}
                className="flex flex-col items-center justify-center h-full min-h-[300px] border-3 border-dashed border-slate-300 rounded-2xl text-slate-400 hover:border-blue-500 hover:text-blue-500 hover:bg-blue-50 transition-all gap-4 group"
              >
                <div className="p-4 bg-slate-100 rounded-full group-hover:bg-blue-100 transition-colors">
                  <Plus size={32} />
                </div>
                <span className="font-bold text-lg">Agregar Nuevo Destino</span>
              </button>

              {destinations.map(dest => {
                 const currentCurrency = dest.pricing?.[0]?.currency || 'USD';
                 const isRoomPricing = isMultiPricing(dest);

                 return (
                  <div key={dest.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden group hover:shadow-md transition-all">
                    <div className="relative h-48 bg-slate-200 group-hover:opacity-90 transition-opacity">
                      <img 
                        src={dest.image} 
                        alt={dest.name} 
                        className="w-full h-full object-cover transition-all"
                        style={{ objectPosition: dest.imagePosition || 'center center' }} 
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                        <button 
                          onClick={() => triggerUpload(dest.id, 'main')}
                          className="bg-white text-slate-900 px-4 py-2 rounded-full font-bold text-sm flex items-center gap-2 hover:scale-105 transition-transform"
                        >
                          {uploadingState?.id === dest.id && uploadingState?.type === 'main' ? <Loader2 className="animate-spin" size={16}/> : <Upload size={16} />}
                          Subir Nueva
                        </button>
                        <button 
                          onClick={() => openMediaLibrary(dest.id, 'main')}
                          className="bg-blue-600 text-white px-4 py-2 rounded-full font-bold text-sm flex items-center gap-2 hover:scale-105 transition-transform"
                        >
                          <ImageIcon size={16} />
                          Usar Existente
                        </button>
                      </div>
                      <div className="absolute top-2 right-2 flex gap-2">
                        <button 
                          onClick={() => handleUpdateDest(dest.id, 'visible', dest.visible === false ? true : false)}
                          className={`${dest.visible !== false ? 'bg-blue-500/80 hover:bg-blue-600' : 'bg-slate-500/80 hover:bg-slate-600'} text-white p-2 rounded-full transition-colors`}
                          title={dest.visible !== false ? "Visible (Click para ocultar)" : "Oculto (Click para mostrar)"}
                        >
                          {dest.visible !== false ? <Eye size={16} /> : <EyeOff size={16} />}
                        </button>
                        <button 
                          onClick={() => removeDest(dest.id)}
                          className="bg-red-500/80 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                          title="Eliminar"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      
                      {/* Position Control Overlay */}
                      <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                         <PositionControl 
                            value={dest.imagePosition} 
                            onChange={(val) => handleUpdateDest(dest.id, 'imagePosition', val)} 
                         />
                      </div>
                    </div>

                    <div className="p-5 space-y-4">
                      <div>
                        <label className="text-xs font-bold text-slate-400 uppercase">Nombre del Viaje</label>
                        <input 
                          type="text" 
                          value={dest.name}
                          onChange={(e) => handleUpdateDest(dest.id, 'name', e.target.value)}
                          className="w-full font-bold text-lg text-slate-800 border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none bg-transparent transition-colors"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-xs font-bold text-slate-400 uppercase">Duración</label>
                          <input 
                            type="text" 
                            value={dest.duration}
                            onChange={(e) => handleUpdateDest(dest.id, 'duration', e.target.value)}
                            className="w-full text-sm text-slate-600 border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none bg-transparent"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-bold text-slate-400 uppercase">Categoría</label>
                          <select 
                            value={dest.category}
                            onChange={(e) => handleUpdateDest(dest.id, 'category', e.target.value)}
                            className="w-full text-sm text-slate-600 border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none bg-transparent py-1"
                          >
                            <option value="Parks">Parques</option>
                            <option value="Tours">Tours</option>
                            <option value="Trips">Viajes</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-xs font-bold text-slate-400 uppercase">WhatsApp para Reservas</label>
                        <select 
                          value={dest.whatsappNumber || '664 760 0861'}
                          onChange={(e) => handleUpdateDest(dest.id, 'whatsappNumber', e.target.value)}
                          className="w-full text-sm font-bold text-green-600 border-b border-transparent hover:border-slate-300 focus:border-green-500 focus:outline-none bg-transparent py-2"
                        >
                          <option value="664 760 0861">664 760 0861</option>
                          <option value="664 594 7666">664 594 7666</option>
                          <option value="663 205 6850">663 205 6850</option>
                        </select>
                      </div>

                      {/* --- PRICING SECTION START --- */}
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                        <div className="flex justify-between items-center mb-3">
                           <label className="text-xs font-bold text-slate-400 uppercase flex items-center gap-1">
                             <span className="text-green-600">Configuración de Precios</span>
                           </label>
                           <select
                              value={currentCurrency}
                              onChange={(e) => updateCurrency(dest.id, e.target.value as 'USD' | 'MXN')}
                              className="text-xs font-bold bg-white border border-slate-200 rounded px-2 py-1 text-slate-700"
                            >
                              <option value="USD">USD</option>
                              <option value="MXN">MXN</option>
                           </select>
                        </div>

                        <div className="mb-3">
                           <div className="flex bg-white rounded-lg p-1 border border-slate-200">
                              <button
                                onClick={() => togglePricingType(dest.id, 'single')}
                                className={`flex-1 py-1.5 text-xs font-bold rounded flex items-center justify-center gap-1 ${!isRoomPricing ? 'bg-blue-100 text-blue-700' : 'text-slate-400 hover:bg-slate-50'}`}
                              >
                                <User size={12} /> Individual
                              </button>
                              <button
                                onClick={() => togglePricingType(dest.id, 'room')}
                                className={`flex-1 py-1.5 text-xs font-bold rounded flex items-center justify-center gap-1 ${isRoomPricing ? 'bg-blue-100 text-blue-700' : 'text-slate-400 hover:bg-slate-50'}`}
                              >
                                <Users size={12} /> Habitaciones
                              </button>
                           </div>
                        </div>

                        {isRoomPricing ? (
                          <div className="space-y-2">
                             <div className="flex items-center justify-between">
                                <span className="text-xs text-slate-500 font-medium">Cuádruple (4 pers)</span>
                                <div className="flex items-center w-24 border-b border-slate-300">
                                   <span className="text-xs text-slate-400 mr-1">$</span>
                                   <input 
                                     type="number"
                                     value={getPriceByPeople(dest, 4)}
                                     onChange={(e) => updatePriceValue(dest.id, 4, parseInt(e.target.value))}
                                     className="w-full text-right font-bold text-slate-700 bg-transparent focus:outline-none" 
                                   />
                                </div>
                             </div>
                             <div className="flex items-center justify-between">
                                <span className="text-xs text-slate-500 font-medium">Triple (3 pers)</span>
                                <div className="flex items-center w-24 border-b border-slate-300">
                                   <span className="text-xs text-slate-400 mr-1">$</span>
                                   <input 
                                     type="number"
                                     value={getPriceByPeople(dest, 3)}
                                     onChange={(e) => updatePriceValue(dest.id, 3, parseInt(e.target.value))}
                                     className="w-full text-right font-bold text-slate-700 bg-transparent focus:outline-none" 
                                   />
                                </div>
                             </div>
                             <div className="flex items-center justify-between">
                                <span className="text-xs text-slate-500 font-medium">Doble (2 pers)</span>
                                <div className="flex items-center w-24 border-b border-slate-300">
                                   <span className="text-xs text-slate-400 mr-1">$</span>
                                   <input 
                                     type="number"
                                     value={getPriceByPeople(dest, 2)}
                                     onChange={(e) => updatePriceValue(dest.id, 2, parseInt(e.target.value))}
                                     className="w-full text-right font-bold text-slate-700 bg-transparent focus:outline-none" 
                                   />
                                </div>
                             </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between pt-2">
                                <span className="text-xs text-slate-500 font-medium">Precio por persona</span>
                                <div className="flex items-center w-32 border-b border-slate-300">
                                   <span className="text-sm text-slate-400 mr-1">$</span>
                                   <input 
                                     type="number"
                                     value={getPriceByPeople(dest, 1)}
                                     onChange={(e) => updatePriceValue(dest.id, 1, parseInt(e.target.value))}
                                     className="w-full text-right text-lg font-bold text-slate-700 bg-transparent focus:outline-none" 
                                   />
                                </div>
                             </div>
                        )}
                      </div>
                      {/* --- PRICING SECTION END --- */}
                      
                       <div>
                        <label className="text-xs font-bold text-slate-400 uppercase">Descripción del Viaje (Detalles completos)</label>
                        <textarea 
                          value={dest.description}
                          onChange={(e) => handleUpdateDest(dest.id, 'description', e.target.value)}
                          className="w-full text-sm text-slate-600 border rounded-lg p-3 mt-1 hover:border-blue-300 focus:border-blue-500 focus:outline-none transition-colors h-32 min-h-[5rem] resize-y leading-relaxed"
                          placeholder="Describe en qué consiste el viaje, la experiencia, qué hace especial a este destino..."
                        />
                      </div>

                       <div>
                        <label className="text-xs font-bold text-slate-400 uppercase">Fechas Disponibles (Texto Personalizado)</label>
                        <textarea 
                          value={dest.dateCustomFormat || dest.dates.join('\n')}
                          onChange={(e) => handleUpdateDest(dest.id, 'dateCustomFormat', e.target.value)}
                          className="w-full text-sm text-slate-600 border rounded-lg p-3 mt-1 hover:border-blue-300 focus:border-blue-500 focus:outline-none transition-colors h-40 min-h-[8rem] resize-y font-mono bg-slate-50"
                          placeholder="Pega aquí la lista de fechas. Para formato calendario usa: '🔵 MES' seguido de 'Día: #'"
                        />
                        <p className="text-[10px] text-slate-400 mt-1">
                          Nota: Para el formato de calendario de Parques, usa encabezados como "🔵 ENERO" y luego "🟢 Sábados: ...". Para viajes normales, solo una lista línea por línea.
                        </p>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                            <label className="text-xs font-bold text-slate-400 uppercase">Galería de Fotos</label>
                            <div className="flex gap-2">
                              <button 
                                  onClick={() => openMediaLibrary(dest.id, 'gallery')}
                                  className="text-xs flex items-center gap-1 text-blue-600 font-bold hover:text-blue-800"
                              >
                                  <ImageIcon size={12} /> Galería
                              </button>
                              <button 
                                  onClick={() => triggerUpload(dest.id, 'gallery')}
                                  className="text-xs flex items-center gap-1 text-blue-600 font-bold hover:text-blue-800"
                              >
                                  <Plus size={12} /> Subir
                              </button>
                            </div>
                        </div>
                        
                        <div className="flex gap-2 overflow-x-auto pb-2 min-h-[60px]">
                            {dest.gallery && dest.gallery.length > 0 ? (
                                dest.gallery.map((img, idx) => (
                                    <div key={idx} className="relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden group/gallery bg-slate-100">
                                        <img src={img} alt="Gallery" className="w-full h-full object-cover" />
                                        
                                        {/* Overlay Controls */}
                                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/gallery:opacity-100 transition-opacity flex flex-col justify-between p-1">
                                            <div className="flex justify-end">
                                               <button 
                                                  onClick={() => removeGalleryImage(dest.id, img)}
                                                  className="bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                                                  title="Eliminar"
                                              >
                                                  <X size={10} />
                                              </button>
                                            </div>
                                            
                                            <div className="flex justify-between w-full">
                                                <button 
                                                  onClick={(e) => { e.stopPropagation(); moveGalleryImage(dest.id, idx, 'left'); }}
                                                  disabled={idx === 0}
                                                  className={`p-1 rounded bg-white/20 hover:bg-white/40 text-white ${idx === 0 ? 'opacity-30 cursor-not-allowed' : ''}`}
                                                >
                                                   <ChevronLeft size={12} />
                                                </button>
                                                <button 
                                                  onClick={(e) => { e.stopPropagation(); moveGalleryImage(dest.id, idx, 'right'); }}
                                                  disabled={idx === dest.gallery!.length - 1}
                                                  className={`p-1 rounded bg-white/20 hover:bg-white/40 text-white ${idx === dest.gallery!.length - 1 ? 'opacity-30 cursor-not-allowed' : ''}`}
                                                >
                                                   <ChevronRight size={12} />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <div className="w-full text-center py-4 bg-slate-50 rounded-lg border border-dashed border-slate-200 text-slate-400 text-xs">
                                    Sin fotos extra
                                </div>
                            )}
                             {uploadingState?.id === dest.id && uploadingState?.type === 'gallery' && (
                                <div className="flex-shrink-0 w-16 h-16 rounded-md bg-slate-100 flex items-center justify-center">
                                    <Loader2 className="animate-spin text-blue-500" size={20} />
                                </div>
                            )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'hero' && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* General Settings Box */}
                  <div className="bg-green-50 p-6 rounded-xl border border-green-100 space-y-4">
                     <div>
                        <h3 className="text-green-900 font-bold flex items-center gap-2 text-lg">
                           <MessageSquare size={24} /> WhatsApp General
                        </h3>
                        <p className="text-green-700 text-sm mt-1">
                           Este número aparecerá en el botón flotante de todas las páginas.
                        </p>
                     </div>
                     <div className="flex items-center gap-2">
                        <span className="text-green-800 font-bold text-sm uppercase">Número:</span>
                        <select 
                           value={whatsappNumber}
                           onChange={(e) => setWhatsappNumber(e.target.value)}
                           className="text-lg font-bold text-green-700 bg-white border-2 border-green-200 rounded-lg px-4 py-2 focus:outline-none focus:border-green-500 shadow-sm cursor-pointer hover:border-green-400 transition-colors w-full"
                        >
                           <option value="664 760 0861">664 760 0861</option>
                           <option value="664 594 7666">664 594 7666</option>
                           <option value="663 205 6850">663 205 6850</option>
                        </select>
                     </div>
                  </div>

                  {/* Carousel Configuration Box */}
                  <div className="bg-purple-50 p-6 rounded-xl border border-purple-100 space-y-4">
                     <div>
                        <h3 className="text-purple-900 font-bold flex items-center gap-2 text-lg">
                           <Clock size={24} /> Configuración del Carrusel
                        </h3>
                        <p className="text-purple-700 text-sm mt-1">
                           Ajusta la velocidad y el estilo de las transiciones.
                        </p>
                     </div>
                     
                     <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label className="text-purple-800 font-bold text-xs uppercase block mb-1">Intervalo (ms)</label>
                            <input 
                                type="number" 
                                value={heroSettings.interval}
                                onChange={(e) => updateHeroSettings('interval', parseInt(e.target.value))}
                                className="w-full text-sm font-bold text-purple-700 bg-white border-2 border-purple-200 rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500"
                                step="500"
                                min="1000"
                            />
                         </div>
                         <div>
                            <label className="text-purple-800 font-bold text-xs uppercase block mb-1">Transición</label>
                            <select 
                               value={heroSettings.transitionType}
                               onChange={(e) => updateHeroSettings('transitionType', e.target.value)}
                               className="w-full text-sm font-bold text-purple-700 bg-white border-2 border-purple-200 rounded-lg px-3 py-2 focus:outline-none focus:border-purple-500"
                            >
                               <option value="fade">Desvanecer (Fade)</option>
                               <option value="slide">Deslizar (Slide)</option>
                            </select>
                         </div>
                     </div>
                  </div>
              </div>

              {/* Global Subtitle Settings */}
              <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                <h3 className="text-blue-900 font-bold flex items-center gap-2 text-lg mb-4">
                  <Type size={24} /> Texto Principal
                </h3>
                <div>
                   <label className="text-blue-800 font-bold text-xs uppercase block mb-1">Subtítulo Global (Debajo del título)</label>
                   <input 
                       type="text" 
                       value={heroSettings.subtitleText}
                       onChange={(e) => updateHeroSettings('subtitleText', e.target.value)}
                       className="w-full text-lg text-blue-900 bg-white border-2 border-blue-200 rounded-lg px-4 py-3 focus:outline-none focus:border-blue-500 shadow-sm"
                       placeholder="Tu próxima aventura comienza aquí..."
                   />
                </div>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6">
                <h3 className="text-slate-800 font-bold flex items-center gap-2">
                  <LayoutTemplate size={20} /> Diapositivas de Portada
                </h3>
                <p className="text-slate-600 text-sm mt-1">
                  Personaliza cada diapositiva con imagen, texto y enlace a un destino específico.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {heroSlides.map((slide, index) => (
                  <div key={slide.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="relative h-64 bg-slate-200 group">
                      <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button 
                          onClick={() => triggerUpload(slide.id.toString(), 'hero')}
                          className="bg-white text-slate-900 px-4 py-2 rounded-full font-bold text-sm flex items-center gap-2 hover:scale-105 transition-transform"
                        >
                          {uploadingState?.id === slide.id.toString() && uploadingState?.type === 'hero' ? <Loader2 className="animate-spin" size={16}/> : <Upload size={16} />}
                          Subir
                        </button>
                        <button 
                          onClick={() => openMediaLibrary(slide.id.toString(), 'hero')}
                          className="bg-blue-600 text-white px-4 py-2 rounded-full font-bold text-sm flex items-center gap-2 hover:scale-105 transition-transform"
                        >
                          <ImageIcon size={16} />
                          Librería
                        </button>
                      </div>
                      <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-xs font-bold backdrop-blur-md">
                        Diapositiva {index + 1}
                      </div>
                    </div>

                    <div className="p-6 space-y-4">
                      <div>
                        <label className="text-xs font-bold text-slate-400 uppercase">Subtítulo (Texto pequeño)</label>
                        <input 
                          type="text" 
                          value={slide.subtitle}
                          onChange={(e) => handleUpdateHero(slide.id, 'subtitle', e.target.value)}
                          className="w-full font-bold text-blue-500 border-b border-slate-200 hover:border-blue-300 focus:border-blue-500 focus:outline-none bg-transparent py-2 transition-colors"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-400 uppercase">Título Principal (Texto grande)</label>
                        <input 
                          type="text" 
                          value={slide.title}
                          onChange={(e) => handleUpdateHero(slide.id, 'title', e.target.value)}
                          className="w-full text-2xl font-black text-slate-800 border-b border-slate-200 hover:border-blue-300 focus:border-blue-500 focus:outline-none bg-transparent py-2 transition-colors"
                        />
                      </div>
                      
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                         <label className="text-xs font-bold text-slate-500 uppercase flex items-center gap-1 mb-2">
                            <LinkIcon size={12} /> Enlace del Botón "Explorar Destino"
                         </label>
                         <select
                            value={slide.destinationId || ''}
                            onChange={(e) => handleUpdateHero(slide.id, 'destinationId', e.target.value)}
                            className="w-full text-sm bg-white border border-slate-200 rounded-md p-2 focus:border-blue-500 outline-none"
                         >
                            <option value="">-- Sin enlace específico (General) --</option>
                            {destinations.map(dest => (
                               <option key={dest.id} value={dest.id}>{dest.name}</option>
                            ))}
                         </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6">
               <div className="flex justify-between items-center bg-blue-50 p-4 rounded-xl border border-blue-100 mb-6">
                <div>
                   <h3 className="text-blue-900 font-bold flex items-center gap-2">
                     <MessageSquare size={20} /> Gestión de Reseñas
                   </h3>
                   <p className="text-blue-700 text-sm mt-1">
                     Administra las opiniones que aparecen en el carrusel.
                   </p>
                </div>
                <button 
                  onClick={addNewReview}
                  className="bg-blue-600 text-white px-4 py-2 rounded-full font-bold text-sm flex items-center gap-2 hover:bg-blue-700 transition-colors shadow-sm"
                >
                  <Plus size={16} /> Agregar Reseña
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {reviews.map((review) => (
                  <div key={review.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden relative">
                     <div className="p-6">
                        <div className="flex justify-between items-start mb-4">
                           <div className="flex items-center gap-3">
                              <div className="relative group/avatar cursor-pointer w-12 h-12">
                                <img src={review.avatar} alt={review.name} className="w-12 h-12 rounded-full object-cover border-2 border-slate-100" />
                                <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover/avatar:opacity-100 transition-opacity" onClick={() => triggerUpload(review.id, 'review-avatar')}>
                                   {uploadingState?.id === review.id && uploadingState?.type === 'review-avatar' ? <Loader2 className="animate-spin text-white" size={12} /> : <Upload className="text-white" size={12} />}
                                </div>
                              </div>
                              <div className="flex-1">
                                 <input 
                                    type="text" 
                                    value={review.name}
                                    onChange={(e) => handleUpdateReview(review.id, 'name', e.target.value)}
                                    className="font-bold text-slate-900 border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none w-full bg-transparent"
                                    placeholder="Nombre del Cliente"
                                 />
                                 <input 
                                    type="text" 
                                    value={review.date}
                                    onChange={(e) => handleUpdateReview(review.id, 'date', e.target.value)}
                                    className="text-xs text-slate-400 border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none w-full bg-transparent mt-1"
                                    placeholder="Fecha (ej. Hace 2 días)"
                                 />
                              </div>
                           </div>
                           <button onClick={() => removeReview(review.id)} className="text-red-400 hover:text-red-600 p-1">
                              <Trash2 size={16} />
                           </button>
                        </div>

                        <div className="flex items-center gap-2 mb-3">
                           <span className="text-xs font-bold text-slate-400 uppercase">Estrellas:</span>
                           <input 
                              type="number" 
                              min="1" 
                              max="5"
                              value={review.rating}
                              onChange={(e) => handleUpdateReview(review.id, 'rating', parseInt(e.target.value))}
                              className="w-12 border rounded text-center font-bold text-yellow-500"
                           />
                        </div>

                        <textarea 
                           value={review.text}
                           onChange={(e) => handleUpdateReview(review.id, 'text', e.target.value)}
                           className="w-full text-sm text-slate-600 border rounded-lg p-3 hover:border-blue-300 focus:border-blue-500 focus:outline-none transition-colors h-24 resize-none"
                           placeholder="Escribe la opinión del cliente..."
                        />

                        <div className="mt-4 pt-4 border-t border-slate-100">
                           <div className="flex justify-between items-center mb-2">
                              <label className="text-xs font-bold text-slate-400 uppercase">Foto de Evidencia (Opcional)</label>
                              <div className="flex gap-2">
                                <button 
                                  onClick={() => openMediaLibrary(review.id, 'review-image')}
                                  className="text-xs text-blue-500 font-bold flex items-center gap-1 hover:text-blue-700"
                                >
                                   <ImageIcon size={12} /> Librería
                                </button>
                                <button 
                                  onClick={() => triggerUpload(review.id, 'review-image')}
                                  className="text-xs text-blue-500 font-bold flex items-center gap-1 hover:text-blue-700"
                                >
                                   <Upload size={12} /> {review.image ? 'Cambiar' : 'Subir'} Foto
                                </button>
                              </div>
                           </div>
                           
                           {review.image ? (
                              <div className="relative h-32 w-full rounded-lg overflow-hidden group/image">
                                 <img src={review.image} alt="Review attachment" className="w-full h-full object-cover" />
                                 <button 
                                    onClick={() => handleUpdateReview(review.id, 'image', undefined)}
                                    className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover/image:opacity-100 transition-opacity"
                                 >
                                    <X size={14} />
                                 </button>
                                 {uploadingState?.id === review.id && uploadingState?.type === 'review-image' && (
                                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                                       <Loader2 className="animate-spin text-white" size={24} />
                                    </div>
                                 )}
                              </div>
                           ) : (
                              <div className="h-12 border-2 border-dashed border-slate-200 rounded-lg flex items-center justify-center text-xs text-slate-400">
                                 {uploadingState?.id === review.id && uploadingState?.type === 'review-image' ? (
                                    <Loader2 className="animate-spin text-blue-500" size={16} />
                                 ) : (
                                    "Sin foto adjunta"
                                 )}
                              </div>
                           )}
                        </div>
                     </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
        
        <div className="bg-slate-50 p-4 text-center text-xs text-slate-400 border-t border-slate-200">
           Recuerda dar clic en "Guardar {activeTab === 'destinations' ? 'Viajes' : activeTab === 'hero' ? 'Portada' : 'Reseñas'}" para aplicar los cambios.
        </div>
      </motion.div>
    </div>
  );
};