import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, useSpring, useMotionValue, useTransform } from 'motion/react';
import imgOffice from 'figma:asset/e3c17ab9087b00737e022b1180742d4eb5ab1327.png';

const Counter = ({ from, to }: { from: number; to: number }) => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true });
  const count = useMotionValue(from);
  const rounded = useTransform(count, (latest) => Math.round(latest));
  const [displayValue, setDisplayValue] = useState(from);

  useEffect(() => {
    if (inView) {
      const controls = {
        stop: () => {},
      };
      
      const duration = 2; // seconds
      const startTime = Date.now();

      const update = () => {
        const now = Date.now();
        const progress = Math.min((now - startTime) / (duration * 1000), 1);
        // Ease out quint
        const ease = 1 - Math.pow(1 - progress, 5);
        
        const current = Math.round(from + (to - from) * ease);
        setDisplayValue(current);

        if (progress < 1) {
          requestAnimationFrame(update);
        }
      };

      requestAnimationFrame(update);
      
      return () => {};
    }
  }, [inView, from, to]);

  return <span ref={ref}>{displayValue.toLocaleString()}</span>;
};

export const AboutSection = () => {
  return (
    <section id="about" className="py-20 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight sm:text-5xl">
            Nosotros
          </h2>
          <div className="w-24 h-1 bg-[#1c85c5] mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          {/* Text Content */}
          <div className="space-y-6 text-lg text-slate-600 leading-relaxed text-justify">
            <p>
              Somos una agencia de viajes con más de 12 años de experiencia, con local establecido y una sólida trayectoria en México y Estados Unidos. Nos especializamos en ofrecer viajes bien organizados, seguros y confiables, enfocados en brindar una experiencia cómoda y sin complicaciones a cada cliente.
            </p>
            <p>
              Ofrecemos tours y transporte privado binacional para particulares, empresas y escuelas, hacia destinos turísticos, parques temáticos y viajes personalizados. Nuestros clientes pueden elegir alguno de nuestros destinos o armar su propio viaje o experiencia con el respaldo de un equipo experto.
            </p>
          </div>

          {/* Image and Counter */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-500">
              <img 
                src={imgOffice} 
                alt="Oficina de Emotion Tours" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none"></div>
              
              <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
                <div className="flex flex-col items-center justify-center bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                  <p className="text-lg font-medium mb-2 uppercase tracking-wider text-blue-200">Viajes realizados</p>
                  <div className="text-5xl font-black text-white flex items-center gap-2">
                    <Counter from={0} to={10875} />
                    <span className="text-[#1c85c5]">+</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-100 rounded-full mix-blend-multiply filter blur-xl opacity-70 -z-10 animate-blob"></div>
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-purple-100 rounded-full mix-blend-multiply filter blur-xl opacity-70 -z-10 animate-blob animation-delay-2000"></div>
          </div>
        </div>
      </div>
    </section>
  );
};
