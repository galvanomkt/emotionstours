import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EmotionLogo } from './EmotionLogo';

export const Navbar = ({ onNavigate }: { onNavigate: (section: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: 'Inicio', id: 'home' },
    { name: 'Parques', id: 'parks' },
    { name: 'Tours', id: 'tours' },
    { name: 'Viajes', id: 'trips' },
    { name: 'Nosotros', id: 'about' },
    { name: 'Contacto', id: 'contact' },
  ];

  const handleNav = (id: string) => {
    onNavigate(id);
    setIsOpen(false);
  };

  return (
    <nav className="fixed w-full z-50 bg-[#1c85c5]/85 backdrop-blur-md shadow-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div 
            className="flex items-center cursor-pointer" 
            onClick={() => handleNav('home')}
          >
            <EmotionLogo className="h-10 md:h-14 w-auto brightness-0 invert" />
          </div>

          <div className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNav(item.id)}
                className="text-white hover:text-blue-100 font-medium transition-colors duration-200 text-lg tracking-wide"
              >
                {item.name}
              </button>
            ))}
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-white">
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="md:hidden absolute top-20 right-4 w-64 bg-white/95 backdrop-blur-xl rounded-3xl shadow-xl border border-blue-100 overflow-hidden"
            style={{ borderRadius: '2rem' }}
          >
            <div className="py-4 px-2 flex flex-col items-center space-y-2">
              {navItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => handleNav(item.id)}
                  className="w-full text-center py-3 text-lg font-bold text-slate-700 hover:text-[#1c85c5] hover:bg-blue-50 rounded-xl transition-all"
                >
                  {item.name}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
