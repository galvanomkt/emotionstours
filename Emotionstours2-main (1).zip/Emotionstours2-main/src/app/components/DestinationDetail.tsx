
import React, { useState } from 'react';
import { Destination } from '../data';
import { Calendar, CheckCircle, MapPin, Users, Plane, Hotel, User, CreditCard, Info, Clock, ArrowLeft, ArrowRight, Bus, Wallet, X, ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// A simple torn paper edge effect using CSS clip-path
const TornTop = () => (
  <div 
    className="absolute -top-3 left-0 w-full h-4 bg-white z-10"
    style={{
      clipPath: 'polygon(0% 100%, 2% 0%, 4% 100%, 6% 0%, 8% 100%, 10% 0%, 12% 100%, 14% 0%, 16% 100%, 18% 0%, 20% 100%, 22% 0%, 24% 100%, 26% 0%, 28% 100%, 30% 0%, 32% 100%, 34% 0%, 36% 100%, 38% 0%, 40% 100%, 42% 0%, 44% 100%, 46% 0%, 48% 100%, 50% 0%, 52% 100%, 54% 0%, 56% 100%, 58% 0%, 60% 100%, 62% 0%, 64% 100%, 66% 0%, 68% 100%, 70% 0%, 72% 100%, 74% 0%, 76% 100%, 78% 0%, 80% 100%, 82% 0%, 84% 100%, 86% 0%, 88% 100%, 90% 0%, 92% 100%, 94% 0%, 96% 100%, 98% 0%, 100% 100%)'
    }}
  />
);

const TornBottom = () => (
  <div 
    className="absolute -bottom-3 left-0 w-full h-4 bg-white z-10"
    style={{
      clipPath: 'polygon(0% 0%, 2% 100%, 4% 0%, 6% 100%, 8% 0%, 10% 100%, 12% 0%, 14% 100%, 16% 0%, 18% 100%, 20% 0%, 22% 100%, 24% 0%, 26% 100%, 28% 0%, 30% 100%, 32% 0%, 34% 100%, 36% 0%, 38% 100%, 40% 0%, 42% 100%, 44% 0%, 46% 100%, 48% 0%, 50% 100%, 52% 0%, 54% 100%, 56% 0%, 58% 100%, 60% 0%, 62% 100%, 64% 0%, 66% 100%, 68% 0%, 70% 100%, 72% 0%, 74% 100%, 76% 0%, 78% 100%, 80% 0%, 82% 100%, 84% 0%, 86% 100%, 88% 0%, 90% 100%, 92% 0%, 94% 100%, 96% 0%, 98% 100%, 100% 0%)'
    }}
  />
);

interface DestinationDetailProps {
  destination: Destination;
  onClose: () => void;
  onBook: (destination: Destination) => void;
}

export const DestinationDetail = ({ destination, onClose, onBook }: DestinationDetailProps) => {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const openLightbox = (index: number) => setLightboxIndex(index);
  const closeLightbox = () => setLightboxIndex(null);

  const nextImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (lightboxIndex !== null && destination.gallery) {
      setLightboxIndex((prev) => (prev! + 1) % destination.gallery!.length);
    }
  };

  const prevImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (lightboxIndex !== null && destination.gallery) {
      setLightboxIndex((prev) => (prev! - 1 + destination.gallery!.length) % destination.gallery!.length);
    }
  };

  // Specific style overrides based on the attached image
  const headerGradient = "bg-gradient-to-r from-blue-600 to-purple-600";
  const yearColor = "text-purple-400";
  
  // Custom Logos for Disney
  const renderHeaderTitle = () => {
    if (destination.id === 'disney') {
      return (
         <div className="flex flex-col items-center gap-6">
            {/* Simulated Logo Effect using typography since we can't fetch official vector assets */}
            <h1 className="text-5xl md:text-8xl font-black text-white text-center drop-shadow-[0_5px_5px_rgba(0,0,0,0.5)] tracking-tighter" style={{ fontFamily: 'serif' }}>
              Disneyland
            </h1>
            <div className="bg-white/20 h-0.5 w-32 rounded-full"></div>
            <h2 className="text-3xl md:text-5xl font-bold text-sky-300 text-center drop-shadow-lg uppercase tracking-widest leading-none">
              California <br/> Adventure
            </h2>
         </div>
      );
    }
    return (
      <h1 className="text-6xl md:text-9xl font-black text-white uppercase tracking-tighter leading-none drop-shadow-2xl">
        {destination.name.split(' ').map((word, i) => (
          <span key={i} className="block">{word}</span>
        ))}
      </h1>
    );
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 overflow-y-auto bg-sky-50"
    >
      <div className="min-h-screen bg-sky-50 relative">
        {/* Navigation / Close */}
        <div className="absolute top-4 left-4 z-50">
          <button 
            onClick={onClose}
            className="bg-white/90 p-3 rounded-full shadow-lg hover:bg-white transition-all text-slate-800"
          >
            <ArrowLeft size={24} />
          </button>
        </div>

        {/* Hero Section of Detail */}
        <div className="relative h-[60vh] md:h-[70vh] w-full overflow-hidden">
          <div className={`absolute inset-0 ${headerGradient} opacity-60 mix-blend-multiply z-10`} />
          <img 
            src={destination.image} 
            alt={destination.name} 
            className="w-full h-full object-cover"
            style={{ objectPosition: destination.imagePosition || 'center' }}
          />
          
          {/* Main Title Overlay */}
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-center p-4">
            {renderHeaderTitle()}
            
            <div className="mt-8 bg-purple-500/80 backdrop-blur-sm text-white px-6 py-2 rounded-full font-bold text-xl uppercase tracking-widest">
              {destination.duration}
            </div>

            {/* Vertical Year */}
            <div className={`hidden md:block absolute left-10 top-1/2 transform -translate-y-1/2 -rotate-90 text-9xl font-black ${yearColor} opacity-50 select-none`}>
              {destination.year}
            </div>
          </div>
        </div>

        {/* Content Section - Paper Style */}
        <div className="relative max-w-5xl mx-auto -mt-20 mb-20 px-4 z-30">
          
          {/* Pricing Paper Strip */}
          <div className="relative bg-white shadow-2xl rounded-sm transition-transform duration-500">
            <TornTop />
            <TornBottom />
            
            <div className="p-8 md:p-12 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/paper.png')]"></div>
              
              <div className="text-center mb-8">
                <div className="inline-block bg-white px-6 py-2 border-2 border-slate-800 shadow-md">
                  <h3 className="text-xl md:text-2xl font-black text-slate-900 uppercase tracking-widest">
                    Precios por Persona
                  </h3>
                </div>
              </div>

              {/* Room Type Label for Trips */}
              {destination.category === 'Trips' && (
                <div className="text-center -mt-4 mb-8">
                   <p className="text-slate-500 font-bold uppercase tracking-widest text-sm bg-slate-100 inline-block px-4 py-1 rounded-full">
                     Habitación para:
                   </p>
                </div>
              )}

              {/* Pricing Logic: Single Tier vs Multi Tier */}
              {destination.pricing.length === 1 ? (
                <div className="flex flex-col items-center justify-center py-4 gap-4">
                  {destination.pricing.map((tier, index) => (
                    <div key={index} className="flex flex-col items-center pt-2">
                      <span className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">
                        {tier.people} {tier.people > 1 ? 'Personas' : 'Persona'}
                      </span>
                      <div className="bg-[#1c85c5] text-white px-10 py-4 rounded-full shadow-lg transform hover:scale-105 transition-all duration-300 flex items-start gap-1">
                        <span className="text-4xl md:text-5xl font-black tracking-tight">
                          ${tier.price.toLocaleString()} 
                        </span>
                        <span className="text-sm font-bold opacity-90 mt-2">{tier.currency}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 divide-y md:divide-y-0 md:divide-x divide-slate-200">
                  {destination.pricing.map((tier, index) => (
                    <div key={index} className="flex flex-col items-center pt-6 md:pt-0">
                      <span className="text-lg font-bold text-slate-500 uppercase tracking-wider mb-2">
                        {tier.people} {tier.people > 1 ? 'Personas' : 'Persona'}
                      </span>
                      <div className="text-4xl md:text-5xl font-black text-slate-800 mb-1">
                        ${tier.price.toLocaleString()} <span className="text-sm align-top font-bold text-slate-400">{tier.currency}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Transport Only Price if exists */}
              {destination.transportPrice && (
                 <div className="mt-8 text-center border-t border-slate-100 pt-6">
                   <p className="text-slate-600 font-bold text-lg">
                     Sólo transporte: <span className="text-2xl text-slate-900">${destination.transportPrice} USD</span>
                   </p>
                 </div>
              )}

              {destination.deposit && (
                <div className="mt-10 text-center">
                  <div className="inline-block w-full md:w-auto bg-purple-600 text-white font-bold py-3 px-8 rounded-sm text-lg shadow-lg">
                    Reserva con: ${destination.deposit} {destination.pricing[0].currency} <span className="mx-2 opacity-50">|</span> 
                    <span className="font-normal text-sm md:text-base ml-2">Liquida {destination.paymentDeadline || 'antes del viaje'}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* New Description Section */}
          <div className="mt-12 max-w-4xl mx-auto text-center">
             <div className="inline-block bg-white px-6 py-2 border-2 border-slate-800 shadow-md mb-6 transform -rotate-1">
                <h3 className="text-xl md:text-2xl font-black text-slate-900 uppercase tracking-widest">
                  Descripción del Viaje
                </h3>
             </div>
             <p className="text-slate-700 text-lg leading-relaxed font-medium whitespace-pre-wrap">
               {destination.description}
             </p>
          </div>

          {/* Details Section */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-12">
            
            {/* Includes Column */}
            <div className="bg-blue-900/5 p-8 rounded-xl border border-blue-900/10">
               <div className="inline-block bg-white px-4 py-1 border border-slate-800 shadow-sm mb-6">
                <h3 className="text-lg font-black text-slate-900 uppercase">Incluye:</h3>
              </div>
              
              <ul className="space-y-4">
                {destination.includes.map((item, i) => {
                  const lower = item.toLowerCase();
                  let Icon = CheckCircle;
                  if (lower.includes('vuelo') || lower.includes('aéreo')) Icon = Plane;
                  else if (lower.includes('transporte') || lower.includes('traslado') || lower.includes('metro')) Icon = Bus;
                  else if (lower.includes('hospedaje') || lower.includes('hotel')) Icon = Hotel;
                  else if (lower.includes('coordinador') || lower.includes('guía')) Icon = User;
                  else if (lower.includes('información') || lower.includes('asesoría')) Icon = Info;
                  else if (lower.includes('entrada') || lower.includes('boleto')) Icon = Wallet; // Ticket icon placeholder

                  return (
                    <li key={i} className="flex items-start">
                      <div className="mr-3 mt-1 text-purple-600">
                        <Icon size={20} />
                      </div>
                      <span className="text-slate-700 font-medium leading-relaxed">{item}</span>
                    </li>
                  );
                })}
              </ul>

              {/* Payment Methods */}
              {destination.paymentMethods && (
                <div className="mt-10">
                   <div className="inline-block bg-white px-4 py-1 border border-slate-800 shadow-sm mb-6">
                    <h3 className="text-lg font-black text-slate-900 uppercase flex items-center gap-2">
                       <Wallet size={18} /> Métodos de Pago
                    </h3>
                  </div>
                  <ul className="grid grid-cols-1 gap-2">
                    {destination.paymentMethods.map((method, i) => (
                      <li key={i} className="flex items-center text-slate-700 text-sm font-medium">
                         <div className="w-1.5 h-1.5 bg-purple-500 rounded-full mr-2"></div>
                         {method}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Right Column: Destinations / Itinerary / Schedule */}
            <div>
              {/* Special Schedule Section for Day Trips */}
              {destination.schedule && (
                <div className="mb-8 bg-purple-50 border border-purple-100 p-6 rounded-lg">
                  <h4 className="font-bold text-purple-900 mb-4 flex items-center gap-2 text-lg uppercase">
                    <Clock size={20} /> Horario
                  </h4>
                  <div className="space-y-3">
                     <div className="flex justify-between items-center border-b border-purple-200 pb-2">
                        <span className="text-purple-800 font-bold">Salida</span>
                        <span className="text-slate-700 font-bold">{destination.schedule.departure}</span>
                     </div>
                     <div className="flex justify-between items-center border-b border-purple-200 pb-2">
                        <span className="text-purple-800 font-bold">Regreso</span>
                        <span className="text-slate-700 font-bold">{destination.schedule.arrival}</span>
                     </div>
                     {destination.schedule.note && (
                       <p className="text-xs text-purple-600 italic mt-2 text-center">{destination.schedule.note}</p>
                     )}
                  </div>
                </div>
              )}

              {/* Meeting Point */}
              {destination.meetingPoint && (
                <div className="mb-8">
                   <div className="inline-block bg-white px-4 py-1 border border-slate-800 shadow-sm mb-4">
                    <h3 className="text-lg font-black text-slate-900 uppercase flex items-center gap-2">
                      <MapPin size={18} /> Punto de Reunión
                    </h3>
                  </div>
                  <p className="text-slate-700 bg-white p-4 rounded-lg shadow-sm border border-slate-100 font-medium">
                    {destination.meetingPoint}
                  </p>
                </div>
              )}

              {destination.destinationsList ? (
                <div className="bg-slate-800 p-8 rounded-xl text-white shadow-xl relative overflow-hidden">
                   <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500 rounded-full filter blur-3xl opacity-20 -mr-10 -mt-10"></div>
                   
                   <div className="inline-block bg-white px-4 py-1 border border-slate-800 shadow-sm mb-6 text-slate-900 relative z-10">
                    <h3 className="text-lg font-black uppercase flex items-center gap-2">
                      <MapPin size={18} /> Destinos
                    </h3>
                  </div>

                  <ul className="grid grid-cols-1 gap-3 relative z-10">
                    {destination.destinationsList.map((place, i) => (
                      <li key={i} className="flex items-center text-lg font-bold">
                        <span className="w-4 h-0.5 bg-purple-400 mr-3"></span>
                        {place}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : destination.itinerary ? (
                <div className="space-y-6">
                  <div className="inline-block bg-white px-4 py-1 border border-slate-800 shadow-sm mb-2">
                    <h3 className="text-lg font-black text-slate-900 uppercase flex items-center gap-2">
                      <Calendar size={18} /> Itinerario
                    </h3>
                  </div>
                  
                  {destination.itinerary.map((day) => (
                    <div key={day.day} className="bg-white p-5 rounded-lg shadow-sm border border-slate-100">
                      <h4 className="font-bold text-purple-700 mb-2">Día {day.day}: {day.title}</h4>
                      <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-2">
                        {day.activities.map((act, idx) => (
                          <li key={idx}>{act}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              ) : null}

              {destination.requirements && (
                <div className="mt-8 bg-amber-50 border border-amber-200 p-6 rounded-lg">
                  <h4 className="font-bold text-amber-800 mb-2 flex items-center gap-2">
                    <Info size={18} /> Requisitos Importantes
                  </h4>
                  <ul className="list-disc list-inside text-amber-900/80 space-y-1 text-sm font-medium">
                    {destination.requirements.map((req, i) => (
                      <li key={i}>{req}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

          </div>

          {/* Gallery Section */}
          {destination.gallery && destination.gallery.length > 0 && (
            <div className="mt-16">
              <div className="text-center mb-8">
                <div className="inline-block bg-white px-6 py-2 border-2 border-slate-800 shadow-md">
                   <h3 className="text-xl font-black text-slate-900 uppercase tracking-widest">
                     Galería
                   </h3>
                </div>
              </div>
              
              {/* Horizontal Scroll Gallery (First 5) */}
              <div className="relative">
                <div className="flex overflow-x-auto snap-x snap-mandatory gap-4 pb-6 px-4 md:justify-center scrollbar-hide">
                  {destination.gallery.slice(0, 5).map((img, idx) => (
                    <motion.div 
                      key={idx}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex-shrink-0 snap-center w-64 h-64 md:w-56 md:h-56 rounded-xl overflow-hidden shadow-lg cursor-pointer border-4 border-white"
                      onClick={() => openLightbox(idx)}
                    >
                      <img src={img} alt={`Gallery ${idx}`} className="w-full h-full object-cover" />
                    </motion.div>
                  ))}
                </div>

                {/* See More Button */}
                <div className="text-center mt-4">
                  <button 
                    onClick={() => openLightbox(0)}
                    className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 font-bold py-2 px-6 rounded-full hover:bg-purple-200 transition-colors shadow-sm"
                  >
                    <ImageIcon size={18} /> Ver más fotos ({destination.gallery.length})
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Dates Section */}
          <div className="mt-16 text-center">
            <h3 className="text-2xl font-bold text-slate-800 mb-8">Fechas Disponibles {destination.year}</h3>
            
            {destination.dateCustomFormat ? (
               (() => {
                 const raw = destination.dateCustomFormat;
                 const lines = raw.split('\n').map(l => l.trim()).filter(l => l);
                 
                 // Heuristic: Check for emojis OR month names at start of line
                 const monthRegex = /^(ENERO|FEBRERO|MARZO|ABRIL|MAYO|JUNIO|JULIO|AGOSTO|SEPTIEMBRE|OCTUBRE|NOVIEMBRE|DICIEMBRE)/i;
                 const emojiRegex = /^[🔵🟢🟠🟣🔴🟡]/;
                 
                 const isCalendarFormat = lines.some(l => emojiRegex.test(l) || (monthRegex.test(l) && !l.includes(':') && !l.includes('-') && l.length < 20));

                 if (isCalendarFormat) {
                    const sections: { title: string, items: string[] }[] = [];
                    let currentSection = { title: '', items: [] as string[] };
                    
                    lines.forEach(line => {
                       const trimmed = line.trim();
                       if (!trimmed) return;

                       const hasEmoji = emojiRegex.test(trimmed);
                       const hasMonth = monthRegex.test(trimmed);
                       
                       // It's a header if it starts with emoji, OR if it matches month regex and looks like a title (short, no dates usually)
                       const isHeader = (hasEmoji && !trimmed.includes(':')) || (hasMonth && !trimmed.includes(':') && !trimmed.includes('-') && trimmed.length < 30);
                       
                       if (isHeader) {
                          if (currentSection.items.length > 0 || currentSection.title) {
                              sections.push(currentSection);
                          }
                          // Remove emoji and leading/trailing whitespace
                          const cleanTitle = trimmed.replace(/^[🔵🟢🟠🟣🔴🟡]\s*/, '').trim();
                          currentSection = { title: cleanTitle, items: [] };
                       } else {
                          currentSection.items.push(trimmed);
                       }
                    });
                    if (currentSection.items.length > 0 || currentSection.title) sections.push(currentSection);

                    return (
                       <div className="relative w-full">
                          <div className="flex overflow-x-auto snap-x snap-mandatory gap-4 pb-6 px-4 md:px-0 scrollbar-hide">
                             {sections.map((sec, idx) => (
                                <div key={idx} className="flex-shrink-0 snap-center w-72 sm:w-80 bg-white rounded-2xl border border-slate-200 shadow-sm p-5 h-full flex flex-col hover:border-purple-300 transition-colors">
                                   <div className="text-center font-black text-slate-800 text-lg uppercase tracking-widest mb-4 border-b border-slate-100 pb-2">
                                      {sec.title}
                                   </div>
                                   <div className="space-y-3 flex-1">
                                      {sec.items.map((item, i) => {
                                         // Expected: "🟢 Sábados: 7 · 14 · 21 · 28" OR "Sábados: 7..."
                                         const parts = item.split(':');
                                         if (parts.length >= 2) {
                                            const label = parts[0].replace(/^[🔵🟢🟠🟣🔴🟡]\s*/, '').trim();
                                            const dates = parts.slice(1).join(':').trim(); 
                                            
                                            return (
                                               <div key={i} className="flex flex-col text-sm border-b border-slate-50 last:border-0 pb-2">
                                                  <span className="font-bold text-slate-500 uppercase text-xs mb-1 text-left">{label}</span>
                                                  <span className="text-slate-900 font-mono text-base tracking-tight text-right font-bold">{dates}</span>
                                               </div>
                                            );
                                         }
                                         // Fallback
                                         return (
                                            <div key={i} className="text-slate-600 text-sm text-center font-medium">
                                               {item}
                                            </div>
                                         );
                                      })}
                                   </div>
                                </div>
                             ))}
                          </div>
                          {/* Hint for scrolling */}
                          <div className="text-center text-xs text-slate-400 mt-2 md:hidden animate-pulse">
                              Desliza para ver más meses ↔
                          </div>
                       </div>
                    );
                 } 
                 
                 // Fallback for "Trips" (List of ranges)
                 return (
                    <div className="grid grid-rows-4 grid-flow-col gap-3 overflow-x-auto snap-x snap-mandatory px-4 pb-4 -mx-4 md:mx-0 md:grid-rows-none md:grid-flow-row md:grid-cols-3 md:overflow-visible md:pb-0 auto-cols-[85vw] md:auto-cols-auto">
                        {lines.map((line, i) => (
                           <div key={i} className="snap-center bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex items-start gap-3 h-full">
                              <div className="text-purple-600 mt-0.5 shrink-0">
                                 <Calendar size={18} />
                              </div>
                              <span className="text-slate-700 font-bold text-sm leading-snug">{line}</span>
                           </div>
                        ))}
                    </div>
                 );
               })()
            ) : (
                <div className="flex flex-wrap justify-center gap-3">
                  {destination.dates.map((date, i) => (
                    <span key={i} className="bg-white border border-slate-200 px-4 py-2 rounded-full text-sm font-medium text-slate-600 shadow-sm hover:border-purple-500 hover:text-purple-600 transition-colors cursor-default">
                      {date}
                    </span>
                  ))}
                </div>
            )}
          </div>

          {/* CTA Footer */}
          <div className="mt-20 flex justify-center pb-20">
            <button 
              onClick={() => {
                const phoneNumber = destination.whatsappNumber ? destination.whatsappNumber.replace(/\s+/g, '') : '6647600861';
                const message = encodeURIComponent(`Hola quiero informacion para viajar a ${destination.name}`);
                window.open(`https://wa.me/52${phoneNumber}?text=${message}`, '_blank');
              }}
              className="bg-slate-900 text-white text-xl font-bold py-4 px-12 rounded-full hover:bg-slate-800 transition-all shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 flex items-center gap-3"
            >
              Reservar Ahora <ArrowRight />
            </button>
          </div>

        </div>
      </div>

      {/* Lightbox for Gallery */}
      <AnimatePresence>
        {lightboxIndex !== null && destination.gallery && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center p-4"
            onClick={closeLightbox}
          >
             <button 
               className="absolute top-4 right-4 text-white/70 hover:text-white p-2"
               onClick={(e) => { e.stopPropagation(); closeLightbox(); }}
             >
               <X size={40} />
             </button>

             {/* Navigation Buttons */}
             <button 
               className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/70 hover:text-white p-4 bg-black/20 hover:bg-black/40 rounded-full transition-colors hidden md:block"
               onClick={prevImage}
             >
               <ChevronLeft size={40} />
             </button>

             <button 
               className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white/70 hover:text-white p-4 bg-black/20 hover:bg-black/40 rounded-full transition-colors hidden md:block"
               onClick={nextImage}
             >
               <ChevronRight size={40} />
             </button>

             <motion.img 
               key={lightboxIndex}
               initial={{ opacity: 0, x: 50 }}
               animate={{ opacity: 1, x: 0 }}
               exit={{ opacity: 0, x: -50 }}
               src={destination.gallery[lightboxIndex]} 
               alt={`Gallery Fullscreen ${lightboxIndex}`} 
               className="max-w-full max-h-[85vh] rounded-md shadow-2xl object-contain select-none" 
               drag="x"
               dragConstraints={{ left: 0, right: 0 }}
               dragElastic={1}
               onDragEnd={(e, { offset, velocity }) => {
                 const swipe = offset.x;
                 if (swipe < -100) nextImage();
                 else if (swipe > 100) prevImage();
               }}
             />

             <div className="absolute bottom-6 left-0 right-0 text-center text-white/50 text-sm font-medium">
                {lightboxIndex + 1} / {destination.gallery.length} • Desliza para navegar
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
