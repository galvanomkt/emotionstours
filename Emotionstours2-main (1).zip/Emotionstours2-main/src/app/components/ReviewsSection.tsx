import React, { useRef } from 'react';
import { Star, ChevronLeft, ChevronRight, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { Review } from '../data';

interface ReviewsSectionProps {
  reviews: Review[];
}

export const ReviewsSection = ({ reviews }: ReviewsSectionProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { current } = scrollRef;
      const scrollAmount = direction === 'left' ? -350 : 350;
      current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 bg-slate-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
             {/* Google G Logo simplified */}
             <svg viewBox="0 0 24 24" className="w-8 h-8" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
             </svg>
             <span className="text-2xl font-bold text-slate-700">Reseñas</span>
          </div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Clientes Satisfechos</h2>
          <div className="flex items-center justify-center gap-1 text-yellow-400 text-xl">
             <span className="font-bold text-slate-900 mr-2">4.9</span>
             {[1,2,3,4,5].map(i => <Star key={i} fill="currentColor" size={20} />)}
             <span className="text-slate-400 text-sm ml-2">(1,100 + Opiniones)</span>
          </div>
        </div>

        {/* Carousel Container */}
        <div className="relative group">
          
          {/* Controls */}
          <button 
            onClick={() => scroll('left')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-20 bg-white/80 p-3 rounded-full shadow-lg text-slate-800 hover:bg-white transition-all hidden md:flex"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button 
            onClick={() => scroll('right')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-20 bg-white/80 p-3 rounded-full shadow-lg text-slate-800 hover:bg-white transition-all hidden md:flex"
          >
            <ChevronRight size={24} />
          </button>

          {/* Scroll Area */}
          <div 
            ref={scrollRef}
            className="flex overflow-x-auto gap-6 px-4 md:px-8 py-8 snap-x snap-mandatory scrollbar-hide"
            style={{ scrollBehavior: 'smooth' }}
          >
            {reviews.map((review, idx) => (
              <motion.div 
                key={review.id || idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.05 }}
                className="flex-shrink-0 w-[300px] md:w-[350px] bg-white p-6 rounded-2xl shadow-md border border-slate-100 relative snap-center"
              >
                 <div className="flex items-center gap-4 mb-4">
                   <img src={review.avatar} alt={review.name} className="w-12 h-12 rounded-full object-cover border-2 border-slate-100" />
                   <div>
                     <h4 className="font-bold text-slate-900">{review.name}</h4>
                     <p className="text-xs text-slate-400">{review.date}</p>
                   </div>
                 </div>
                 
                 <div className="flex text-yellow-400 mb-3">
                   {[...Array(review.rating)].map((_, i) => <Star key={i} fill="currentColor" size={16} />)}
                 </div>

                 <p className="text-slate-600 text-sm leading-relaxed">
                   "{review.text}"
                 </p>
                 
                 {review.image && (
                    <div className="mt-4 rounded-lg overflow-hidden h-32 w-full">
                       <img src={review.image} alt="Review" className="w-full h-full object-cover" />
                    </div>
                 )}

                 {/* Google logo watermark */}
                 <div className="absolute bottom-4 right-4 opacity-10 grayscale">
                    <svg viewBox="0 0 24 24" className="w-6 h-6" fill="currentColor">
                       <path d="M21.35 11.1h-9.17v2.98h3.39c-.18 1.15-1.37 3.38-3.39 3.38-2.07 0-3.77-1.74-3.77-3.87s1.7-3.87 3.77-3.87c1.03 0 1.95.4 2.56.96l1.97-1.96C15.42 7.56 13.8 7 12.18 7 9.32 7 7 9.32 7 12.18s2.32 5.18 5.18 5.18c2.99 0 4.98-2.11 4.98-5.07 0-.39-.03-.7-.1-1.19z"/>
                    </svg>
                 </div>
              </motion.div>
            ))}
          </div>
        </div>
        
        <div className="mt-10 text-center">
          <a 
            href="https://maps.app.goo.gl/BVwMWdNm2ePvFfaHA" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 text-purple-600 font-bold hover:text-purple-700 hover:underline transition-all transform hover:scale-105"
          >
            <MapPin size={18} /> Ver todas las opiniones en Google Maps 
          </a>
        </div>
      </div>
    </section>
  );
};
