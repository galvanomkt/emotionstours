
export type Category = 'Parks' | 'Tours' | 'Trips';

export interface PricingTier {
  people: number;
  price: number;
  currency: string;
}

export interface Destination {
  id: string;
  name: string;
  category: Category;
  year: number;
  duration: string;
  image: string;
  description: string;
  dates: string[];
  pricing: PricingTier[];
  deposit?: number;
  paymentDeadline?: string;
  transportPrice?: number;
  meetingPoint?: string;
  schedule?: { departure: string; arrival: string; note?: string };
  paymentMethods?: string[];
  includes: string[];
  destinationsList?: string[]; // For the "Destinos" list in the flyer
  itinerary?: { day: number; title: string; activities: string[] }[];
  requirements?: string[];
  gallery?: string[];
  logos?: string[]; // URLs for official logos
  dateCustomFormat?: string; // New field for complex date descriptions
  whatsappNumber?: string; // Contact number for booking
  imagePosition?: string; // CSS object-position value (e.g., 'center', 'top', 'bottom', '0% 20%')
  visible?: boolean; // Controls visibility of the destination
}

export interface Review {
  id: string;
  name: string;
  date: string;
  rating: number;
  text: string;
  avatar: string;
  image?: string; // Optional image attached to the review
}

export const defaultReviews: Review[] = [
  {
    id: '1',
    name: "Karla Mendez",
    date: "Hace 2 semanas",
    rating: 5,
    text: "Contratamos el tour a Disney y fue maravilloso. El coordinador nos ayudó en todo momento con la app y los tiempos. ¡Súper recomendados!",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '2',
    name: "Jorge Luis",
    date: "Hace 1 mes",
    rating: 5,
    text: "Excelente servicio para ir al Valle de Guadalupe. La camioneta muy limpia, moderna y el chofer super prudente en la carretera.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '3',
    name: "Mónica Arellano",
    date: "Hace 1 mes",
    rating: 5,
    text: "Mis papás fueron a Chiapas con ellos y regresaron encantados. Se sintieron muy seguros y bien atendidos todo el viaje.",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '4',
    name: "Ricardo T.",
    date: "Hace 2 meses",
    rating: 5,
    text: "La mejor opción en Tijuana para viajes grupales. Fui a Las Vegas y el ambiente del grupo fue lo mejor. Definitivamente repetiré.",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '5',
    name: "Sofia G.",
    date: "Hace 2 meses",
    rating: 5,
    text: "Súper recomendados. Resolvieron todas mis dudas sobre los requisitos de la Visa antes de reservar. Muy honestos.",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '6',
    name: "Familia Torres",
    date: "Hace 3 meses",
    rating: 5,
    text: "Gracias a Emotion Tours por hacer el cumpleaños de mi hija en Six Flags tan especial. Todo salió perfecto.",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '7',
    name: "Alex B.",
    date: "Hace 3 meses",
    rating: 5,
    text: "Buenos precios y facilidades de pago. He viajado 3 veces con ellos y nunca he tenido un problema.",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '8',
    name: "Brenda L.",
    date: "Hace 4 meses",
    rating: 5,
    text: "El tour a Real del Castillo y la Ruta del Queso estuvo delicioso. Una experiencia diferente y muy divertida.",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '9',
    name: "David P.",
    date: "Hace 5 meses",
    rating: 5,
    text: "Muy profesionales. La oficina en Rio te da mucha confianza para hacer los pagos y reservar. 10/10.",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: '10',
    name: "Fernanda M.",
    date: "Hace 6 meses",
    rating: 5,
    text: "Increíble experiencia en el Gran Cañón. Los hoteles que eligieron estaban muy bien y el paisaje es irreal.",
    avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=150"
  }
];

export const destinations: Destination[] = [
  {
    id: 'disney',
    name: 'Disneyland Park',
    category: 'Parks',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1645570044132-e0a51fc0962e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxEaXNuZXlsYW5kJTIwQ2FsaWZvcm5pYSUyMGNhc3RsZSUyMGZpcmV3b3Jrc3xlbnwxfHx8fDE3NzAyNDQzNzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Donde los sueños se hacen realidad. Visita el lugar más feliz de la tierra.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 299, currency: 'USD' }],
    deposit: 40,
    paymentDeadline: '3 días antes del viaje',
    transportPrice: 65,
    meetingPoint: 'Glorieta Diana Cazadora Y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '5:00 am (Estar 30 min antes)',
      arrival: '1:00 am (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    includes: [
      'Transporte redondo',
      'Seguro viajero',
      'Boleto de entrada',
      'Coordinador durante el viaje'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1624310025270-7b05f4f9736d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxEaXNuZXlsYW5kJTIwcmlkZXMlMjBmdW58ZW58MXx8fHwxNzcwMjQ0OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1740889089600-16e60695db99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxNaWNrZXklMjBNb3VzZSUyMEZlcnJpcyUyMFdoZWVsJTIwQ2FsaWZvcm5pYSUyMEFkdmVudHVyZXxlbnwxfHx8fDE3NzAyNDQ5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1700182580617-6e51fbd59f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTdGFyJTIwV2FycyUyMEdhbGF4eXMlMjBFZGdlJTIwRGlzbmV5bGFuZHxlbnwxfHx8fDE3NzAyNDQ5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1560111161-f63eda4518fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDYXJzJTIwTGFuZCUyMERpc25leSUyMENhbGlmb3JuaWElMjBBZHZlbnR1cmV8ZW58MXx8fHwxNzcwMjQ0OTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    ],
    logos: []
  },
  {
    id: 'disney-copy-1',
    name: 'Disneyland Park (Copia 1)',
    category: 'Parks',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1645570044132-e0a51fc0962e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxEaXNuZXlsYW5kJTIwQ2FsaWZvcm5pYSUyMGNhc3RsZSUyMGZpcmV3b3Jrc3xlbnwxfHx8fDE3NzAyNDQzNzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Donde los sueños se hacen realidad. Visita el lugar más feliz de la tierra.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 299, currency: 'USD' }],
    deposit: 40,
    paymentDeadline: '3 días antes del viaje',
    transportPrice: 65,
    meetingPoint: 'Glorieta Diana Cazadora Y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '5:00 am (Estar 30 min antes)',
      arrival: '1:00 am (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    includes: [
      'Transporte redondo',
      'Seguro viajero',
      'Boleto de entrada',
      'Coordinador durante el viaje'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1624310025270-7b05f4f9736d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxEaXNuZXlsYW5kJTIwcmlkZXMlMjBmdW58ZW58MXx8fHwxNzcwMjQ0OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1740889089600-16e60695db99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxNaWNrZXklMjBNb3VzZSUyMEZlcnJpcyUyMFdoZWVsJTIwQ2FsaWZvcm5pYSUyMEFkdmVudHVyZXxlbnwxfHx8fDE3NzAyNDQ5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1700182580617-6e51fbd59f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTdGFyJTIwV2FycyUyMEdhbGF4eXMlMjBFZGdlJTIwRGlzbmV5bGFuZHxlbnwxfHx8fDE3NzAyNDQ5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1560111161-f63eda4518fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDYXJzJTIwTGFuZCUyMERpc25leSUyMENhbGlmb3JuaWElMjBBZHZlbnR1cmV8ZW58MXx8fHwxNzcwMjQ0OTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    ],
    logos: []
  },
  {
    id: 'disney-copy-2',
    name: 'Disneyland Park (Copia 2)',
    category: 'Parks',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1645570044132-e0a51fc0962e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxEaXNuZXlsYW5kJTIwQ2FsaWZvcm5pYSUyMGNhc3RsZSUyMGZpcmV3b3Jrc3xlbnwxfHx8fDE3NzAyNDQzNzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Donde los sueños se hacen realidad. Visita el lugar más feliz de la tierra.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 299, currency: 'USD' }],
    deposit: 40,
    paymentDeadline: '3 días antes del viaje',
    transportPrice: 65,
    meetingPoint: 'Glorieta Diana Cazadora Y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '5:00 am (Estar 30 min antes)',
      arrival: '1:00 am (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    includes: [
      'Transporte redondo',
      'Seguro viajero',
      'Boleto de entrada',
      'Coordinador durante el viaje'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1624310025270-7b05f4f9736d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxEaXNuZXlsYW5kJTIwcmlkZXMlMjBmdW58ZW58MXx8fHwxNzcwMjQ0OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1740889089600-16e60695db99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxNaWNrZXklMjBNb3VzZSUyMEZlcnJpcyUyMFdoZWVsJTIwQ2FsaWZvcm5pYSUyMEFkdmVudHVyZXxlbnwxfHx8fDE3NzAyNDQ5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1700182580617-6e51fbd59f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTdGFyJTIwV2FycyUyMEdhbGF4eXMlMjBFZGdlJTIwRGlzbmV5bGFuZHxlbnwxfHx8fDE3NzAyNDQ5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1560111161-f63eda4518fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxDYXJzJTIwTGFuZCUyMERpc25leSUyMENhbGlmb3JuaWElMjBBZHZlbnR1cmV8ZW58MXx8fHwxNzcwMjQ0OTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    ],
    logos: []
  },
  {
    id: 'new-york',
    name: 'Nueva York',
    category: 'Trips',
    year: 2026,
    duration: '4 Días | 3 Noches',
    image: 'figma:asset/b7e077e40acb1721a89be71b0b1d9aafb5e39169.png',
    description: 'Vive la experiencia de la Gran Manzana con nuestro tour exclusivo.',
    dates: ['Octubre 15-18, 2025', 'Noviembre 20-23, 2025'],
    dateCustomFormat: `NEW YORK 2026
Del Miércoles 11 al Domingo 15 de Febrero
Del Jueves 12 al Lunes 16 de Marzo
Del Jueves 26 al Lunes 30 de Marzo
Del Jueves 02 al Lunes 06 de Abril
Del Jueves 30 de Abril al Lunes 04 de Mayo
Del Miércoles 20 al Domingo 24 de Mayo
Del Miércoles 17 al Domingo 21 de Junio
Del Jueves 16 al Lunes 20 de Julio
Del Miércoles 05 al Domingo 09 de Agosto
Del Jueves 10 al lunes 14 de Septiembre
Del Viernes 11 al Martes 15 de Septiembre
Del Sábado 12 al Miércoles 16 de Septiembre
Del Miércoles 14 al Domingo 18 de Octubre
Del Jueves 12 al Lunes 16 de Noviembre
Del Miércoles 18 al Domingo 22 de Noviembre`,
    pricing: [
      { people: 2, price: 1350, currency: 'USD' },
      { people: 3, price: 1150, currency: 'USD' },
      { people: 4, price: 1050, currency: 'USD' },
    ],
    deposit: 300,
    paymentDeadline: '10 días antes del viaje',
    includes: [
      'Información y asesoría previa a tu viaje',
      'Vuelo redondo y directo desde San Diego',
      'Hospedaje de 3 noches en Manhattan',
      'Coordinador durante el viaje',
      'Pase de transporte MetroCard ilimitado',
      'Itinerario digital y Kit de regalo',
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    meetingPoint: 'Aeropuerto Internacional de San Diego (SAN)',
    schedule: {
      departure: 'Según itinerario de vuelo',
      arrival: 'Según itinerario de vuelo',
      note: 'Se requiere estar 3 horas antes del vuelo'
    },
    requirements: [
      'VISA VIGENTE y PASAPORTE VIGENTE',
      'Permiso I-94 (Si aplica)',
      'Maleta de mano (Carry On) 10kg',
      'Artículo personal (Mochila)',
      'La mejor actitud y ganas de viajar'
    ],
    destinationsList: [
      'Time Square',
      'Central Park',
      'The Summit',
      'Empire State',
      'Estatua de la libertad',
      'Puente de Brooklyn',
      'Brooklyn Promenade',
      'Museo MOMA',
    ],
    gallery: [
       'figma:asset/b7e077e40acb1721a89be71b0b1d9aafb5e39169.png',
       'https://images.unsplash.com/photo-1496442226666-8d4a0e62e6e9?q=80&w=1080&auto=format&fit=crop',
       'https://images.unsplash.com/photo-1546436836-07a91091f16f?q=80&w=1080&auto=format&fit=crop'
    ]
  },
  {
    id: 'las-vegas',
    name: 'Las Vegas',
    category: 'Trips',
    year: 2026,
    duration: '3 Días | 2 Noches',
    image: 'https://images.unsplash.com/photo-1601056645460-05fd9ad8f4e0?q=80&w=1080&auto=format&fit=crop',
    description: 'La capital del entretenimiento mundial te espera.',
    dates: [
      'Enero 15-17', 'Febrero 12-14', 'Marzo 20-22', 'Abril 10-12', 
      'Mayo 15-17', 'Junio 12-14', 'Julio 10-12', 'Agosto 14-16',
      'Septiembre 11-13', 'Octubre 16-18', 'Noviembre 13-15', 'Diciembre 11-13', 'Diciembre 29-31'
    ],
    dateCustomFormat: `LAS VEGAS 2026
Fechas
Del Viernes 13 al Domingo 15 de Febrero
Del Sábado 14 al Lunes 16 de Marzo
Del Viernes 03 al Domingo 05 de Abril
Del Viernes 01 al Domingo 03 de Mayo
Del Viernes 29 al Domingo 31 de Mayo
Del Viernes 12 al Domingo 14 de Junio
Del Viernes 24 al Domingo 26 de Julio
Del Lunes 10 al Miércoles 12 de Agosto
Del Viernes 18 al Domingo 20 de Septiembre
Del Viernes 9 al Domingo 11 de Octubre
Del Sábado 14 al Lunes 16 de Noviembre 
Del Viernes 20 al Domingo 22 de Noviembre
Del Viernes 11 al Domingo 13 de Diciembre`,
    pricing: [
      { people: 2, price: 290, currency: 'USD' },
      { people: 3, price: 260, currency: 'USD' },
      { people: 4, price: 230, currency: 'USD' },
    ],
    includes: [
      'Transporte redondo desde Tijuana/San Diego/Los Angeles',
      'Hospedaje en hotel en el Strip',
      'Coordinador de grupo',
      'Traslados a los puntos de interés',
      'Snacks y bebidas en el transporte'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '12:00 AM (Medianoche)',
      arrival: '10:00 PM (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    itinerary: [
      { day: 1, title: 'Llegada y Luces', activities: ['Salida de puntos de reunión', 'Check-in Hotel', 'Tour nocturno por el Strip', 'Espectáculo de fuentes Bellagio'] },
      { day: 2, title: 'Exploración y Shows', activities: ['Mañana libre / Pool party', 'Visita a Fremont Street', 'Noche libre para shows o casinos'] },
      { day: 3, title: 'Compras y Regreso', activities: ['Check-out', 'Parada en Seven Magic Mountains', 'Outlet Shopping', 'Regreso a casa'] }
    ],
    requirements: ['Visa vigente', 'Pasaporte vigente', 'Mayoría de edad para casinos'],
    gallery: [
      'https://images.unsplash.com/photo-1605833556294-ea5c7a74f57d?q=80&w=1080&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1581351123004-75798061660f?q=80&w=1080&auto=format&fit=crop'
    ]
  },
  {
    id: 'ruta-vino',
    name: 'Ruta del Vino',
    category: 'Tours',
    year: 2026,
    duration: '1 Día',
    image: 'figma:asset/4c0aab145f7925037ba542c29dec4e28140a8936.png',
    description: 'Valle de Guadalupe, Ensenada y La Bufadora.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 450, currency: 'MXN' }],
    deposit: 200,
    paymentDeadline: '5 días antes del viaje',
    includes: [
      'Transporte redondo',
      'Degustaciones',
      'Agua embotellada',
      'Seguro Viajero',
      'Coordinador durante el viaje',
      'Dinámicas y regalos',
      'Opcional: Buffet (+$250 MXN)'
    ],
    destinationsList: [
      'Sol de Media Noche', 
      'Vinos Victor', 
      'Rancho Las Delicias', 
      'Letras Valle de Guadalupe', 
      'La Bufadora', 
      'Malecón de Ensenada'
    ],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '7:00 AM (Estar 30 min antes)',
      arrival: '9:00 PM (Aproximadamente)',
    },
    requirements: [
       'Vestir cómodamente y de acuerdo al clima',
       'Protector solar (importante)',
       'Llevar almohada y cobija viajera',
       'Llevar audífonos y cargador externo',
       'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Pago online', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
       'figma:asset/4c0aab145f7925037ba542c29dec4e28140a8936.png',
       'figma:asset/cfa4f5a5498b51300f64617771c93a3c2a1f5bdc.png',
       'https://images.unsplash.com/photo-1642141143981-95c52021f780?q=80&w=1080&auto=format&fit=crop'
    ]
  },
  {
    id: 'universal',
    name: 'Universal Studios Hollywood',
    category: 'Parks',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1604261622543-be7da1e4f520?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVbml2ZXJzYWwlMjBTdHVkaW9zJTIwSG9sbHl3b29kJTIwZ2xvYmUlMjBmb3VudGFpbiUyMGVudHJhbmNlfGVufDF8fHx8MTc3MDM0NDM3OXww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Luces, cámara, acción. Vive la magia del cine en Hollywood.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 205, currency: 'USD' }],
    deposit: 40,
    paymentDeadline: '3 días antes del viaje',
    transportPrice: 65,
    meetingPoint: 'Glorieta Diana Cazadora Y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '5:00 am (Estar 30 min antes)',
      arrival: '1:00 am (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    includes: [
      'Transporte redondo',
      'Seguro viajero',
      'Boleto de entrada',
      'Coordinador durante el viaje'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'La mejor actitud y ganas de viajar',
      'Visitar sitio web para mapa y shows'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1631730125349-ec0f99c0dbe5?q=80&w=1080', // Harry Potter Castle
      'https://images.unsplash.com/photo-1629646526325-d4e092b641b3?q=80&w=1080', // Mario Kart
      'https://images.unsplash.com/photo-1648633183851-1407829c4540?q=80&w=1080', // Studio Tour
      'https://images.unsplash.com/photo-1652752447700-218435abeb12?q=80&w=1080', // Jurassic World
      'https://images.unsplash.com/photo-1535496821524-1170ddfa6f38?q=80&w=1080', // Simpsons
      'https://images.unsplash.com/photo-1570155913390-639d9cb06572?q=80&w=1080', // WaterWorld
      'https://images.unsplash.com/photo-1730130856221-e44ff6dd519a?q=80&w=1080', // Transformers
      'https://images.unsplash.com/photo-1604261622543-be7da1e4f520?q=80&w=1080', // Globe
      'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=1080', // Generic Fun
      'https://images.unsplash.com/photo-1596282052402-23f2628469d7?q=80&w=1080'  // Generic Minion vibe
    ]
  },
  {
    id: 'six-flags',
    name: 'Six Flags Magic Mountain',
    category: 'Parks',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1593372415526-956ba6725857?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTaXglMjBGbGFncyUyME1hZ2ljJTIwTW91bnRhaW4lMjByb2xsZXIlMjBjb2FzdGVyJTIwc2t5bGluZXxlbnwxfHx8fDE3NzAzNDQyODZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'La capital mundial de las montañas rusas.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 125, currency: 'USD' }],
    deposit: 40,
    paymentDeadline: '3 días antes del viaje',
    transportPrice: 65,
    meetingPoint: 'Glorieta Diana Cazadora Y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '5:00 am (Estar 30 min antes)',
      arrival: '1:00 am (Aproximadamente)',
    },
    includes: [
      'Transporte redondo',
      'Seguro viajero',
      'Boleto de entrada',
      'Coordinador durante el viaje'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1593372415526-956ba6725857?q=80&w=1080', // Skyline
      'https://images.unsplash.com/photo-1627482940262-d5eabda2c31c?q=80&w=1080', // Goliath
      'https://images.unsplash.com/photo-1731209272485-1c8f0d95d797?q=80&w=1080', // Full Throttle
      'https://images.unsplash.com/photo-1604852459475-633c9ed98f62?q=80&w=1080', // Drop
      'https://images.unsplash.com/photo-1513883049090-d0b7439799bf?q=80&w=1080', // Coaster
      'https://images.unsplash.com/photo-1502136969935-8d8eef54d77b?q=80&w=1080', // Coaster
      'https://images.unsplash.com/photo-1555462557-013061327c13?q=80&w=1080', // Coaster
      'https://images.unsplash.com/photo-1470290374971-7788a1099684?q=80&w=1080', // Coaster
      'https://images.unsplash.com/photo-1627482940262-d5eabda2c31c?q=80&w=1080', // Duplicate Goliath as placeholder
      'https://images.unsplash.com/photo-1593372415526-956ba6725857?q=80&w=1080'  // Duplicate Skyline
    ]
  },
  {
    id: 'knotts',
    name: 'Knott\'s Berry Farm',
    category: 'Parks',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1669694009203-4f6b8c975c5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxLbm90dCUyN3MlMjBCZXJyeSUyMEZhcm0lMjByb2xsZXIlMjBjb2FzdGVyfGVufDF8fHx8MTc3MDM0NDM5MHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'El primer parque temático de California, famoso por Snoopy y sus pays.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 125, currency: 'USD' }],
    deposit: 40,
    paymentDeadline: '3 días antes del viaje',
    transportPrice: 65,
    meetingPoint: 'Glorieta Diana Cazadora Y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '5:00 am (Estar 30 min antes)',
      arrival: '1:00 am (Aproximadamente)',
    },
    includes: [
      'Transporte redondo',
      'Seguro viajero',
      'Boleto de entrada',
      'Coordinador durante el viaje'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1724501919562-3993113f01a0?q=80&w=1080', // HangTime
      'https://images.unsplash.com/photo-1741979882730-35154c3c271e?q=80&w=1080', // Xcelerator
      'https://images.unsplash.com/photo-1657875861302-bccc11dad8b8?q=80&w=1080', // Boysenberry
      'https://images.unsplash.com/photo-1669694009203-4f6b8c975c5e?q=80&w=1080', // Coaster
      'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=1080', // Western
      'https://images.unsplash.com/photo-1525203303664-9b5894b84b55?q=80&w=1080', // Coaster
      'https://images.unsplash.com/photo-1551024601-564552277d33?q=80&w=1080', // Food
      'https://images.unsplash.com/photo-1554189097-ffe88e998a2b?q=80&w=1080', // Park
      'https://images.unsplash.com/photo-1519077203650-70f2f360742f?q=80&w=1080', // Park
      'https://images.unsplash.com/photo-1528659556950-c65074220301?q=80&w=1080'  // Park
    ]
  },
  {
    id: 'gran-canon',
    name: 'Gran Cañón',
    category: 'Trips',
    year: 2026,
    duration: '2 Días | 1 Noche',
    image: 'https://images.unsplash.com/photo-1585202899963-de85e5f9b357?q=80&w=1080&auto=format&fit=crop',
    description: 'Una de las maravillas naturales del mundo.',
    dates: ['Mayo 15-16', 'Junio 20-21'],
    dateCustomFormat: `GRAN CANYON 2026
FECHAS 2026
Del Sábado 14 al lunes 16 de Marzo
Del Viernes 03 al Domingo 5 de Abril
Del Viernes 10 de abril al Domingo 12 de Abril
Del Viernes 1 de Mayo al Domingo 3 de Mayo
Del Viernes 05 al Domingo 07 de Junio
Del Viernes 10 al Domingo 12 de Julio
Del Lunes 20 de Julio al Miércoles 22 de Julio
Del Viernes 07 al Domingo 09 de Agosto
Del Viernes 11 al Domingo 13 de Septiembre
Del Sábado 14 al Lunes 16 de Noviembre`,
    pricing: [
      { people: 2, price: 350, currency: 'USD' },
      { people: 3, price: 320, currency: 'USD' },
      { people: 4, price: 300, currency: 'USD' },
    ],
    includes: ['Transporte redondo', 'Hospedaje', 'Entrada al parque nacional', 'Coordinador'],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '10:00 PM (Noche anterior)',
      arrival: '10:00 PM (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Ropa cómoda y de acuerdo al clima',
      'Protector solar',
      'La mejor actitud y ganas de viajar'
    ],
    destinationsList: [
      'Gran Cañon',
      'Mather Point',
      'Yavapai Geology Museum',
      'Grand Canyon Village',
      'Seligman (Ruta 66)'
    ]
  },
  {
    id: 'san-francisco',
    name: 'San Francisco',
    category: 'Trips',
    year: 2026,
    duration: '4 Días | 3 Noches',
    image: 'https://images.unsplash.com/photo-1670351502052-458736107ce1?q=80&w=1080&auto=format&fit=crop',
    description: 'El puente Golden Gate y la niebla te esperan.',
    dates: ['Julio 10-13', 'Agosto 14-17'],
    dateCustomFormat: `SAN FRANCISCO 2026
FECHAS
Del Viernes 13 al Lunes 16 de Marzo
Del Viernes 27 al Lunes 30 de Marzo
Del Jueves 02 al Domingo 05 de Abril
Del Jueves 16 al Domingo 19 de Abril
Del Jueves 30 de Abril al Domingo 03 de Mayo
Del Jueves 18 al Domingo 21 de Junio
Del Jueves 16 al Domingo 19 de Julio
Del Domingo 26 al Miercoles 29 de Julio
Del Jueves 13 al Domingo 16 de Agosto
Del Jueves 10 al Domingo 13 de Septiembre
Del Jueves 22 al Domingo 25 de Octubre
Del Viernes 13 al Lunes 16 de Noviembre`,
    pricing: [
      { people: 2, price: 450, currency: 'USD' },
      { people: 3, price: 420, currency: 'USD' },
      { people: 4, price: 390, currency: 'USD' },
    ],
    includes: ['Transporte', 'Hospedaje', 'Visita a Golden Gate', 'Pier 39', 'Lombard Street'],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '10:00 PM (Noche anterior)',
      arrival: '10:00 PM (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Ropa cómoda y de acuerdo al clima',
      'Cámara fotográfica',
      'La mejor actitud y ganas de viajar'
    ],
    destinationsList: ['Golden Gate Bridge', 'Fisherman\'s Wharf', 'Lombard Street', 'Alcatraz (opcional)', 'Union Square', 'Chinatown']
  },
  {
    id: 'yosemite',
    name: 'Yosemite Parque Nacional',
    category: 'Trips',
    year: 2026,
    duration: '3 Días | 2 Noches',
    image: 'https://images.unsplash.com/photo-1765873360348-dfcdc90c3b08?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxZb3NlbWl0ZSUyME5hdGlvbmFsJTIwUGFyayUyMHNjZW5pYyUyMHZpZXclMjB3YXRlcmZhbGwlMjBlbCUyMGNhcGl0YW58ZW58MXx8fHwxNzcwMzQzNjIzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Conecta con la naturaleza en uno de los parques más impresionantes del mundo.',
    dates: [
      'Marzo 19-22', 'Abril 30 - Mayo 03', 'Mayo 14-17', 
      'Junio 18-21', 'Julio 16-19', 'Agosto 27-30', 
      'Septiembre 24-27', 'Octubre 15-18', 'Noviembre 05-08'
    ],
    dateCustomFormat: `YOSEMITE NATIONAL PARK 2026
Del Jueves 19 al Domingo 22 de Marzo
Del Jueves 30 de Abril al Domingo 03 de Mayo
Del Jueves 14 de Mayo al Domingo 17 de Mayo 
Del Jueves 18 al Domingo 21 de Junio
Del Jueves 16 al Domingo 19 de Julio
Del Jueves 27 al Domingo 30 de Agosto
Del Jueves 24 al Domingo 27 de Septiembre
Del Jueves 15 al Domingo 18 de Octubre
Del Jueves 05 al Domingo 08 de Noviembre`,
    pricing: [
      { people: 2, price: 380, currency: 'USD' },
      { people: 3, price: 350, currency: 'USD' },
      { people: 4, price: 310, currency: 'USD' },
    ],
    deposit: 150,
    paymentDeadline: '5 días antes del viaje',
    includes: [
      'Transporte Redondo',
      '1 Dia en Yosemite Valley',
      '1 Dia en Yosemite Mariposa Grove',
      'Hotel 2 noches',
      'Guia Durante el Viaje',
      'Bebidas y Snacks'
    ],
    destinationsList: ['Yosemite Valley', 'Mariposa Grove', 'Túnel View', 'El Capitán', 'Bridalveil Fall'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '11:00 PM (San Ysidro)',
      arrival: '10:00 PM (Tijuana)',
      note: 'Salida frente a Starbucks San Ysidro. Estar 55min antes.'
    },
    requirements: ['Visa vigente', 'Permiso I-94'],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1765873360348-dfcdc90c3b08?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxZb3NlbWl0ZSUyME5hdGlvbmFsJTIwUGFyayUyMHNjZW5pYyUyMHZpZXclMjB3YXRlcmZhbGwlMjBlbCUyMGNhcGl0YW58ZW58MXx8fHwxNzcwMzQzNjIzfDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1636266608829-ceb30b335302?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxZb3NlbWl0ZSUyMHZhbGxleSUyMHR1bm5lbCUyMHZpZXd8ZW58MXx8fHwxNzcwMzQzNjIzfDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1589132223049-36171d18f8dc?q=80&w=1080&auto=format&fit=crop'
    ]
  },
  {
    id: 'sequoia',
    name: 'Sequoia National Park',
    category: 'Trips',
    year: 2026,
    duration: '3 Días | 2 Noches',
    image: 'https://images.unsplash.com/photo-1543855493-537d70083278?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTZXF1b2lhJTIwTmF0aW9uYWwlMjBQYXJrJTIwZ2lhbnQlMjB0cmVlcyUyMGZvcmVzdHxlbnwxfHx8fDE3NzAzNDM2MjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Camina entre gigantes milenarios en el bosque más grande del mundo.',
    dates: [
      'Abril 02-05', 'Abril 30 - Mayo 03', 'Mayo 21-24', 
      'Junio 25-28', 'Julio 23-26', 'Agosto 20-23', 
      'Septiembre 12-15', 'Octubre 29 - Nov 01', 'Noviembre 19-22'
    ],
    dateCustomFormat: `SEQUOIA NATIONAL PARK 2026
Del Jueves 02 al Domingo 05 de Abril
Del Jueves 30 de Abril del al domingo 03 de Mayo
Del Jueves 21 al Domingo 24 de Mayo
Del Jueves 25 al Domingo 28 de Junio
Del Jueves 23 al Domingo 26 de Julio
Del Jueves 20 al Domingo 23 de Agosto
Del Viernes 11 al Lunes 14 de Septiembre
Del Jueves 29 Octubre al Domingo 1 de Noviembre
Del Jueves 19 al Domingo 22 de Noviembre`,
    pricing: [
      { people: 2, price: 340, currency: 'USD' },
      { people: 3, price: 290, currency: 'USD' },
      { people: 4, price: 280, currency: 'USD' },
    ],
    deposit: 150,
    paymentDeadline: '5 días antes del viaje',
    includes: [
      'Transporte Redondo',
      '1 Dia en Sequoia',
      '1 Dia en Kings Canyon',
      'Hospedaje de 2 noches',
      'Guia Durante el Viaje',
      'Bebidas y Snacks'
    ],
    destinationsList: ['General Sherman Tree', 'Kings Canyon', 'Tunnel Log', 'Moro Rock'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '11:00 PM (San Ysidro)',
      arrival: '10:00 PM (Tijuana)',
      note: 'Salida frente a Starbucks San Ysidro. Estar 55min antes.'
    },
    requirements: ['Visa vigente', 'Permiso I-94'],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1543855493-537d70083278?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTZXF1b2lhJTIwTmF0aW9uYWwlMjBQYXJrJTIwZ2lhbnQlMjB0cmVlcyUyMGZvcmVzdHxlbnwxfHx8fDE3NzAzNDM2MjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1688602384734-677a13efe6ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxHZW5lcmFsJTIwU2hlcm1hbiUyMFRyZWUlMjBTZXF1b2lhfGVufDF8fHx8MTc3MDM0MzYyNHww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1518090382791-7649553f1947?q=80&w=1080&auto=format&fit=crop'
    ]
  },
  {
    id: 'california-tour',
    name: 'California Tour',
    category: 'Tours',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1757478935057-f71d1f2eb683?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxTYW50YSUyME1vbmljYSUyMFBpZXIlMjBmZXJyaXMlMjB3aGVlbCUyMHN1bnNldHxlbnwxfHx8fDE3NzA2NzIxODh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Descubre los iconos de Los Ángeles en un día inolvidable.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 60, currency: 'USD' }],
    deposit: 15,
    paymentDeadline: '3 días antes del viaje',
    includes: ['Transporte redondo', 'Guía durante el viaje', 'Cortesía de bebidas y snacks', 'Tiempo libre', 'Seguro viajero'],
    destinationsList: ['Observatorio Griffith', 'Hollywood Walk of fame', 'Santa Mónica', 'City Walk'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '06:00 am (Estar 30 min antes)',
      arrival: '10:30 pm (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'Planear e investigar actividades a realizar',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1757478935057-f71d1f2eb683?q=80&w=1080',
      'https://images.unsplash.com/photo-1675308620565-ffe32e481ac6?q=80&w=1080',
      'https://images.unsplash.com/photo-1534008757030-27299c4371b6?q=80&w=1080'
    ]
  },
  {
    id: 'cultural-trip',
    name: 'Cultural Trip',
    category: 'Tours',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1550866526-4b4b702287af?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVcmJhbiUyMExpZ2h0JTIwTEFDTUElMjBMb3MlMjBBbmdlbGVzfGVufDF8fHx8MTc3MDY3MjE4OHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Arte, cultura y los mejores spots fotográficos de Los Ángeles.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 60, currency: 'USD' }],
    deposit: 15,
    paymentDeadline: '3 días antes del viaje',
    includes: ['Transporte redondo', 'Guía durante el viaje', 'Tiempo libre', 'Cortesía de bebidas y snacks', 'Seguro viajero'],
    destinationsList: ['The Broad', 'Grand Central Market', 'Public Art Urban Light', 'The Last Bookstore', 'La Brea tar Pits', 'The Grove L.A.', 'Museum MOCA'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '06:00 am (Estar 30 min antes)',
      arrival: '10:30 pm (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'Planear e investigar actividades a realizar',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1550866526-4b4b702287af?q=80&w=1080',
      'https://images.unsplash.com/photo-1600935100679-a205a54a1e61?q=80&w=1080',
      'https://images.unsplash.com/photo-1518659160566-a4c00445fb80?q=80&w=1080'
    ]
  },
  {
    id: 'sd-julian',
    name: 'SD Julián Tour',
    category: 'Tours',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1697163132513-d76ad38c507b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxKdWxpYW4lMjBDYWxpZm9ybmlhJTIwdG93biUyMGFwcGxlJTIwcGllfGVufDF8fHx8MTc3MDY3MjE4OHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Disfruta del encanto de Julian y lo mejor de San Diego.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 40, currency: 'USD' }],
    deposit: 15,
    paymentDeadline: '3 días antes del viaje',
    includes: ['Seguro viajero', 'Transporte redondo', 'Coordinador de viaje', 'Visita a puntos turísticos'],
    destinationsList: ['Balboa Park', 'Seaport Village', 'Julian Town', 'Old Town S.D.'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '06:00 am (Estar 30 min antes)',
      arrival: '10:30 pm (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'Planear e investigar actividades a realizar',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1697163132513-d76ad38c507b?q=80&w=1080',
      'https://images.unsplash.com/photo-1707078515416-d86759251d21?q=80&w=1080',
      'https://images.unsplash.com/photo-1542345749-33b000499092?q=80&w=1080'
    ]
  },
  {
    id: 'big-bear',
    name: 'Big Bear Lake',
    category: 'Tours',
    year: 2026,
    duration: '1 Día',
    image: 'https://images.unsplash.com/photo-1652905982267-8003fe5e9a10?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxCaWclMjBCZWFyJTIwTGFrZSUyMHNub3clMjB3aW50ZXJ8ZW58MXx8fHwxNzcwNjcyMTg4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Nieve, diversión y paisajes increíbles en la montaña.',
    dates: ['Temporada Invernal'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 65, currency: 'USD' }],
    deposit: 15,
    paymentDeadline: '3 días antes del viaje',
    includes: ['Transporte redondo', 'Seguro viajero', 'Coordinador de grupo', 'Tiempo libre en la nieve'],
    destinationsList: ['Big Bear Lake', 'The Village', 'Snow Play Area'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '06:00 am (Estar 30 min antes)',
      arrival: '10:30 pm (Aproximadamente)',
      note: 'Posible salida de San Ysidro'
    },
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar o llevar lunch',
      'Vestir cómodamente y de acuerdo al clima',
      'Llevar audífonos y cargador externo',
      'Planear e investigar actividades a realizar',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
      'https://images.unsplash.com/photo-1652905982267-8003fe5e9a10?q=80&w=1080',
      'https://images.unsplash.com/photo-1549887534-1541e9326642?q=80&w=1080',
      'https://images.unsplash.com/photo-1548777123-e216912df7d8?q=80&w=1080'
    ]
  },
  {
    id: 'san-pedro-martir',
    name: 'San Pedro Mártir',
    category: 'Tours',
    year: 2026,
    duration: '1 Día',
    image: 'figma:asset/0739a3cbccf80be038010e09a1b687dcbb1ec9eb.png',
    description: 'El punto más alto de Baja California y sus cielos estrellados.',
    dates: ['Temporada Invernal'],
    dateCustomFormat: `FEBRERO
Sábados 21 y 28
Domingos 22
Miércoles 25 ( NO SIX)
Viernes 20 y 27

MARZO
Sábados 7, 14, 21 Y 28
Domingos 1, 8, 15 y 22
Lunes 16 y 30 
Miércoles 4, 11, 18 y 25 ( 4,11,18 NO SIX ) 
Viernes 13, 20 Y 27

ABRIL
Sábados 4, 11, 18 y 25
Domingos 5, 12, 19 y 26
Miércoles 1, 8, 15, 22 y 29 (15 y 22  NO SIX)
Viernes 3, 10 y 24
Jueves 2, 9 y 30
Lunes 6

MAYO
Sábados 2, 9, 16, 23 Y 30
Domingos 3, 10, 17, 24, 31
Lunes 4, 18 Y 25
Miércoles 6, 13, 20 Y 27
Viernes 1, 8, 15 y 29
Martes 5 

JUNIO
Sábados 6, 13, 20 y 27
Domingos 7, 14, 21 y 28
Lunes 22 y 29
Miércoles 3, 10, 17 y 24
Viernes 19 y 26
Jueves 25`,
    pricing: [{ people: 1, price: 1400, currency: 'MXN' }],
    deposit: 300,
    paymentDeadline: '3 días antes del viaje',
    includes: [
      'Seguro viajero',
      'Transporte redondo',
      'Lunch',
      'Caminata por la montaña',
      'Observatorio astronómico (Sujeto a disponibilidad)'
    ],
    destinationsList: ['Observatorio Astronómico', 'Parque Nacional', 'Miradores'],
    meetingPoint: 'Glorieta Diana Cazadora y Ley Pueblo Amigo, Tijuana',
    schedule: {
      departure: '4:00 AM (Estar 30 min antes)',
      arrival: '10:30 PM (Aproximadamente)',
    },
    requirements: [
       'Vestir con ropa adecuada para el frio y el hiking',
       'Se recomienda llevar lunch y snacks para el resto del día',
       'Llevar audífonos y cargador externo',
       'La mejor actitud para divertirte y viajar',
       'Nota: La caída de nieve no se garantiza 100% por ser fenómeno natural'
    ],
    paymentMethods: ['Depósitos', 'Transferencia electrónica', 'Depósito en banco', 'Pago online', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
       'figma:asset/0739a3cbccf80be038010e09a1b687dcbb1ec9eb.png',
       'figma:asset/7b49334f94e363df1f49c38df41c5a426fe0ff45.png',
       'https://images.unsplash.com/photo-1724494513061-4ece38df45c7?q=80&w=1080'
    ]
  },
  {
    id: 'mulege',
    name: 'Mulegé',
    category: 'Trips',
    year: 2026,
    duration: '4 Días / 3 Noches',
    image: 'figma:asset/8b635e3285dc4f95b31bb4a9770c9715beefcbad.png',
    description: 'Descubre el oasis de Baja California Sur, playas vírgenes y misiones históricas.',
    dates: [
      'Marzo 27-31', 'Abril 01-05', 'Abril 05-09', 'Abril 08-12',
      'Mayo 13-17', 'Junio 17-21', 'Julio 08-12', 'Julio 22-26',
      'Agosto 05-09', 'Agosto 19-23', 'Septiembre 12-16', 'Octubre 14-18', 'Noviembre 12-16'
    ],
    dateCustomFormat: `MULEGÉ 2026
Viernes 27 al Martes 31 de Marzo
Miércoles 01 al Domingo 05 de Abril
Domingo 05 al Jueves 09 de Abril
Miércoles 08 al Domingo 12 de Abril
Miércoles 13 al Domingo 17 de Mayo
Miércoles 17 al Domingo 21 de Junio
Miércoles 08 al Domingo 12 de Julio
Miércoles 22 al Domingo 26 de Julio
Miércoles 05 al Domingo 09 de Agosto
Miércoles 19 al Domingo 23 de Agosto
Sábado 12 al Miércoles 16 de Septiembre
Miércoles 14 al Domingo 18 de Octubre
Jueves 12 al Lunes 16 de Noviembre`,
    pricing: [
      { people: 2, price: 4800, currency: 'MXN' },
      { people: 3, price: 4300, currency: 'MXN' },
      { people: 4, price: 3900, currency: 'MXN' },
    ],
    deposit: 1000,
    paymentDeadline: '5 días antes del viaje',
    includes: [
      'Hospedaje 4 días y 3 noches',
      'Seguro viajero',
      'Transporte redondo',
      'Guía/Coordinador durante el viaje',
      'Cortesía de bebidas y snacks durante el viaje',
      'Visita y misión de Santa Rosalía y San Ignacio',
      'Visita a Playas: Santispac, El Burro y Requesón',
      'Visita y tiempo libre en el pueblo de Santa Rosalía'
    ],
    destinationsList: [
        'Mulegé', 'Santa Rosalía', 'San Ignacio', 'Playa Santispac', 'Playa El Burro', 'Playa El Requesón', 'Misión San Ignacio'
    ],
    meetingPoint: 'Glorieta Diana Cazadora (Plaza Pueblo Amigo)',
    schedule: {
      departure: '6:00 p.m. (Estar 45min antes)',
      arrival: '2:00 a.m. (Aproximadamente)',
    },
    itinerary: [
      {
        day: 1,
        title: 'Salida',
        activities: [
            '6:00 pm - Salida de Tijuana (Estar 45 min. antes)',
            'Paradas exprés durante el camino Tijuana-Mulegé. Para compra de alimentos y servicio de sanitarios (De 15 a 20 Min).'
        ]
      },
      {
        day: 2,
        title: 'Santa Rosalía y Mulegé',
        activities: [
            '10 am / 11:00 am - Llegada a Santa Rosalía.',
            'Tiempo libre para desayuno y actividades individuales.',
            '11 am / 12:00 pm - Salida de Santa Rosalía a Mulegé.',
            '1:00 pm - Llegada a Mulegé Aprox. Check In - Entrega de Habitaciones',
            '3:00 pm - Salida de hotel a Playa Santispac.',
            '6:00 pm - Regreso a hotel y resto de la tarde libre.'
        ]
      },
      {
        day: 3,
        title: 'Playa El Burro y Misión',
        activities: [
            '9:30 am - Salida de hotel a Playa El Burro.',
            '4:00 pm - Salida de playa hacia la Misión de St. Rosalía y Mirador.',
            '5:00 pm - Regreso a hotel y resto de la tarde libre.'
        ]
      },
      {
        day: 4,
        title: 'Playa El Requesón',
        activities: [
            '9:30 AM - Salida a Playa El Requesón.',
            '4:30 PM - Regreso a hotel y resto de la tarde libre.'
        ]
      },
      {
        day: 5,
        title: 'Regreso',
        activities: [
            '9:30 AM - Entrega de llaves a recepción y tiempo para compras. (Snacks/Bebidas)',
            '12:00 PM - Salida de hotel, de regreso a Tijuana.',
            'Parada con visita Misión San Ignacio. 30 minutos libres para conocer y tomar fotografías',
            '7 PM / 8:00 PM - Parada para cenar en San Quintín. (No incluida)',
            '1:30 AM - Llegada aproximada a Tijuana.'
        ]
      }
    ],
    requirements: [
        'Llevar hielera, sillas de playa, sombrillas o carpas',
        'Maleta lista días antes de viajar / etiquetar equipaje',
        'Botiquín de primeros auxilios',
        'Almohada de viaje y protector solar',
        'Investigar y planear de acuerdo a itinerario',
        'Llevar comida para la estancia en la playa',
        'Llevar audífonos y cargador externo',
        'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['OXXO', 'Transferencia', 'Depósito bancario', 'Mercado Pago', 'Efectivo/Tarjeta en Oficina'],
    gallery: [
        'figma:asset/8b635e3285dc4f95b31bb4a9770c9715beefcbad.png',
        'figma:asset/b22a6f30e16e9948e44eb895a525a8da1adb7d20.png',
        'figma:asset/63f9f5ea514c042a5d04a453b35d2efe3a18fc77.png',
        'https://images.unsplash.com/photo-1559663738-9556276274e1?q=80&w=1080',
        'https://images.unsplash.com/photo-1512100356356-de1b84283e18?q=80&w=1080'
    ]
  },
  {
    id: 'disney-2days',
    name: 'Disneyland 2 Días',
    category: 'Parks',
    year: 2026,
    duration: '2 Días | 1 Noche',
    image: 'figma:asset/3d7a6ee8c783d8da3c46f02dcdd0e7471f7d720b.png',
    description: 'La experiencia completa de Disney. Disfruta de Disneyland y California Adventure en dos días llenos de magia.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: 'Salidas los Sábados\nRegreso Domingo en la madrugada',
    pricing: [
        { people: 1, price: 540, currency: 'USD' }
    ],
    deposit: 100,
    paymentDeadline: '05 días antes del viaje',
    meetingPoint: 'Starbucks San Ysidro',
    schedule: {
      departure: '6:00 am (Estar 45 minutos antes)',
      arrival: '01:00 am (Aproximadamente) a Tijuana',
    },
    includes: [
      'Transporte redondo',
      'Traslado a los parques',
      'Boleto 1 día Disneyland Park',
      'Boleto 1 día Disney California Adventure',
      'Hospedaje 1 noche',
      'Desayuno continental (Sujeto a disponibilidad)'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar antes o llevar lunch a bordo',
      'Vestir cómodamente y de acuerdo al clima',
      'Visitar Disneyland.com para consultar mapas, atracciones, shows, actividades y faqs',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['Depósitos en OXXO', 'Transferencia electrónica', 'Deposito en banco / cajero automático', 'Tarjeta de débito y/ o crédito', 'Oficina'],
    gallery: [
       'figma:asset/3d7a6ee8c783d8da3c46f02dcdd0e7471f7d720b.png',
       'https://images.unsplash.com/photo-1541364983171-a8ba01e95cfc?q=80&w=1080',
       'https://images.unsplash.com/photo-1628191011993-4350f92696bb?q=80&w=1080'
    ]
  },
  {
    id: 'disney-universal',
    name: 'Disneyland + Universal',
    category: 'Parks',
    year: 2026,
    duration: '2 Días | 1 Noche',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=1080',
    description: 'Combina la magia de Disney con la acción de Universal Studios en un viaje increíble de fin de semana.',
    dates: ['Sábados y Domingos'],
    dateCustomFormat: 'Salidas los Sábados\nRegreso Domingo en la madrugada',
    pricing: [{ people: 1, price: 560, currency: 'USD' }],
    deposit: 100,
    paymentDeadline: '05 días antes del viaje',
    meetingPoint: 'Starbucks San Ysidro',
    schedule: {
      departure: '6:00 am (Estar 45 minutos antes)',
      arrival: '01:00 am (Aproximadamente) a Tijuana',
    },
    includes: [
      'Transporte redondo',
      'Traslado a los parques',
      'Boleto 1 día Disneyland Park',
      'Boleto 1 día Universal Studios Hollywood',
      'Hospedaje 1 noche',
      'Desayuno continental (Sujeto a disponibilidad)'
    ],
    requirements: [
      'VISA VIGENTE y PERMISO I-94',
      'Se recomienda desayunar antes o llevar lunch a bordo',
      'Vestir cómodamente y de acuerdo al clima',
      'Visitar sitios web oficiales para consultar mapas y horarios',
      'La mejor actitud y ganas de viajar'
    ],
    paymentMethods: ['Depósitos en OXXO', 'Transferencia electrónica', 'Deposito en banco / cajero automático', 'Tarjeta de débito y/ o crédito', 'Oficina'],
    gallery: [
       'https://images.unsplash.com/photo-1525203303664-9b5894b84b55?q=80&w=1080',
       'https://images.unsplash.com/photo-1596282052402-23f2628469d7?q=80&w=1080'
    ]
  }
];
