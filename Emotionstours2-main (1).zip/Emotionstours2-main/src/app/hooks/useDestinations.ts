import { useState, useEffect } from 'react';
import { Destination, destinations as defaultDestinations, Review, defaultReviews } from '../data';
import { projectId, publicAnonKey } from '../../../utils/supabase/info';
import { toast } from 'sonner';

const SERVER_URL = `https://${projectId}.supabase.co/functions/v1/make-server-2afecbd0`;

export interface HeroSlide {
  id: number;
  image: string;
  title: string;
  subtitle: string;
  destinationId?: string;
}

export interface HeroSettings {
  interval: number;
  transitionType: 'fade' | 'slide';
  subtitleText: string;
}

const defaultHeroSlides: HeroSlide[] = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1632970055818-b2d80b1b674d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXNuZXklMjBjYXN0bGUlMjBmaXJld29ya3MlMjB0aGVtZSUyMHBhcmt8ZW58MXx8fHwxNzcwNjgxMzk3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Magia en Familia",
    subtitle: "Vive la experiencia Disney",
    destinationId: "disney"
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1543175547-faf7863981a8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFuZCUyMGNhbnlvbiUyMGxhbmRzY2FwZSUyMG5hdHVyZXxlbnwxfHx8fDE3NzA2ODEzOTd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Naturaleza Pura",
    subtitle: "Explora el Gran Cañón",
    destinationId: "gran-canon"
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1601056645460-05fd9ad8f4e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXMlMjB2ZWdhcyUyMHN0cmlwJTIwbmlnaHQlMjBjaXR5JTIwbGlnaHRzfGVufDF8fHx8MTc3MDY4MTM5N3ww&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Vida Nocturna",
    subtitle: "Diviértete en Las Vegas",
    destinationId: "las-vegas"
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1714412192114-61dca8f15f68?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcGFyYWRpc2UlMjB2YWNhdGlvbnxlbnwxfHx8fDE3NzA2MjU1NDF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Relax Total",
    subtitle: "Descubre Mulegé",
    destinationId: "mulege"
  }
];

const defaultHeroSettings: HeroSettings = {
  interval: 6000,
  transitionType: 'fade',
  subtitleText: 'Tu próxima aventura comienza aquí. Descubre los mejores destinos con Emotion Tours.'
};

export function useDestinations() {
  const [destinations, setDestinations] = useState<Destination[]>(defaultDestinations);
  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>(defaultHeroSlides);
  const [heroSettings, setHeroSettings] = useState<HeroSettings>(defaultHeroSettings);
  const [reviews, setReviews] = useState<Review[]>(defaultReviews);
  const [whatsappNumber, setWhatsappNumber] = useState<string>('664 760 0861');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      await Promise.all([fetchDestinations(), fetchHero(), fetchReviews(), fetchSettings()]);
    } catch (err) {
      console.error(err);
      setError('Error loading data');
    } finally {
      setLoading(false);
    }
  };

  const fetchSettings = async () => {
    try {
      if (!projectId) return; // Skip if no project ID
      
      const response = await fetch(`${SERVER_URL}/settings`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      if (response.ok) {
        const data = await response.json();
        if (data && data.whatsappNumber) {
          setWhatsappNumber(data.whatsappNumber);
        }
        if (data && data.heroSettings) {
          setHeroSettings(data.heroSettings);
        }
      }
    } catch (err) {
      // Silently fail for settings, use defaults. 
      // This is expected on fresh installs or if server is sleeping.
      console.log("Settings fetch info:", err);
    }
  };

  const saveSettings = async (settings: { whatsappNumber: string, heroSettings?: HeroSettings }) => {
    try {
      const response = await fetch(`${SERVER_URL}/settings`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settings)
      });
      if (!response.ok) throw new Error('Failed to save settings');
      setWhatsappNumber(settings.whatsappNumber);
      if (settings.heroSettings) {
        setHeroSettings(settings.heroSettings);
      }
      toast.success('Configuración guardada');
      return true;
    } catch (err) {
      console.error(err);
      toast.error('Error al guardar configuración');
      return false;
    }
  };

  const fetchReviews = async () => {
    try {
      if (!projectId) return;

      const response = await fetch(`${SERVER_URL}/reviews`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      if (!response.ok) throw new Error('Error connecting to server');
      const data = await response.json();
      
      if (Array.isArray(data) && data.length > 0) {
        setReviews(data);
      } else {
        // Only attempt to save defaults if we successfully connected but found no data
        await saveReviews(defaultReviews);
      }
    } catch (err) {
      console.warn("Reviews fetch failed, using defaults.");
    }
  };

  const saveReviews = async (newReviews: Review[]) => {
    try {
      const response = await fetch(`${SERVER_URL}/reviews`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newReviews)
      });
      if (!response.ok) throw new Error('Failed to save');
      setReviews(newReviews);
      toast.success('Reseñas guardadas');
      return true;
    } catch (err) {
      console.error(err);
      toast.error('Error al guardar reseñas');
      return false;
    }
  };

  const fetchDestinations = async () => {
    try {
      if (!projectId) return;

      const response = await fetch(`${SERVER_URL}/destinations`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      if (!response.ok) throw new Error('Error connecting to server');
      const data = await response.json();
      
      if (Array.isArray(data) && data.length > 0) {
        let hasChanges = false;
        
        // 1. Start with server data map for easy access
        const serverMap = new Map(data.map((d: any) => [d.id, d]));
        const merged: Destination[] = [];

        // 2. Process all default destinations (Code Source of Truth for existence/structure updates)
        defaultDestinations.forEach(defDest => {
          const srvDest = serverMap.get(defDest.id);
          
          if (srvDest) {
            // Exists in both. Check for "Migration" needs (e.g. updating date format from old to new)
            // Heuristic: Old format started with emoji "🔵", New format starts with text "FEBRERO" (or similar)
            // We ONLY update dateCustomFormat if it looks like the old version and we have a new version.
            let updatedDest = { ...srvDest };
            
            // Fix: Check if server has old date format (starts with emoji) and code has new format (no emoji at start)
            const serverDateStartsEmoji = srvDest.dateCustomFormat?.trim().startsWith('🔵');
            const defaultDateStartsEmoji = defDest.dateCustomFormat?.trim().startsWith('🔵');
            
            if (serverDateStartsEmoji && !defaultDateStartsEmoji) {
               console.log(`Migrating date format for ${defDest.name}`);
               updatedDest.dateCustomFormat = defDest.dateCustomFormat;
               hasChanges = true;
            }

            // Also ensure "visible" property exists (migration for visibility feature)
            if (updatedDest.visible === undefined && defDest.visible !== undefined) {
                updatedDest.visible = defDest.visible;
                hasChanges = true;
            }

            merged.push(updatedDest);
            serverMap.delete(defDest.id); // Mark as processed
          } else {
            // New in Code -> Add to Merged
            console.log(`Adding new destination from code: ${defDest.name}`);
            merged.push(defDest);
            hasChanges = true;
          }
        });

        // 3. Add remaining server destinations (User created ones)
        serverMap.forEach((srvDest) => {
           merged.push(srvDest);
        });

        if (hasChanges) {
           console.log("Syncing merged definitions to server...");
           setDestinations(merged);
           await saveDestinations(merged);
        } else {
           setDestinations(data);
        }
      } else {
        await saveDestinations(defaultDestinations);
      }
    } catch (err) {
      console.warn("Destinations fetch failed, using defaults.");
    }
  };

  const fetchHero = async () => {
    try {
      if (!projectId) return;

      const response = await fetch(`${SERVER_URL}/hero`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      if (!response.ok) throw new Error('Error connecting to server');
      const data = await response.json();
      
      if (Array.isArray(data) && data.length > 0) {
        setHeroSlides(data);
      } else {
        await saveHero(defaultHeroSlides);
      }
    } catch (err) {
      console.warn("Hero fetch failed, using defaults.");
    }
  };

  const saveDestinations = async (newDestinations: Destination[]) => {
    try {
      const response = await fetch(`${SERVER_URL}/destinations`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newDestinations)
      });
      if (!response.ok) throw new Error('Failed to save');
      setDestinations(newDestinations);
      toast.success('Destinos guardados');
      return true;
    } catch (err) {
      console.error(err);
      toast.error('Error al guardar destinos');
      return false;
    }
  };

  const saveHero = async (newSlides: HeroSlide[]) => {
    try {
      const response = await fetch(`${SERVER_URL}/hero`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newSlides)
      });
      if (!response.ok) throw new Error('Failed to save');
      setHeroSlides(newSlides);
      toast.success('Portada guardada');
      return true;
    } catch (err) {
      console.error(err);
      toast.error('Error al guardar portada');
      return false;
    }
  };

  const compressImage = async (file: File): Promise<Blob> => {
    // 1. Basic format check
    if (file.type === 'image/heic' || file.name.toLowerCase().endsWith('.heic')) {
      throw new Error('El formato HEIC (iPhone) no es compatible. Por favor convierte la imagen a JPG.');
    }
    
    // Skip compression for GIFs to preserve animation
    if (file.type === 'image/gif') {
        return file; // Return original file as blob
    }

    console.log(`Attempting to compress: ${file.name} (${file.type}, ${file.size} bytes)`);

    return new Promise((resolve, reject) => {
      const maxWidth = 1600; // Slightly smaller max width for safety
      const maxHeight = 1600;
      
      // 2. Use URL.createObjectURL instead of FileReader for better memory handling
      const objectUrl = URL.createObjectURL(file);
      const img = new Image();
      
      img.onload = () => {
        // Clean up memory immediately
        URL.revokeObjectURL(objectUrl);

        let width = img.width;
        let height = img.height;

        // Calculate new dimensions
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Could not get canvas context'));
          return;
        }

        // Draw image to canvas
        ctx.drawImage(img, 0, 0, width, height);
        
        // Export to Blob
        canvas.toBlob((blob) => {
          if (blob) {
            // Check if the blob is actually smaller; if not, use original (rare for huge images)
            // But we always want to return blob to ensure it's a valid JPG
            resolve(blob);
          } else {
            reject(new Error('Compression resulted in empty file'));
          }
        }, 'image/jpeg', 0.8); // 80% quality is usually indistinguishable but much lighter
      };
      
      img.onerror = (e) => {
        URL.revokeObjectURL(objectUrl);
        console.error("Image loading error for compression:", e);
        reject(new Error(`La imagen no se pudo leer. Puede estar dañada o formato incorrecto. Tipo: ${file.type}`));
      };

      img.src = objectUrl;
    });
  };

  const uploadImage = async (file: File): Promise<string | null> => {
    try {
      let fileToUpload: File | Blob = file;
      
      // Only compress images
      if (file.type.startsWith('image/')) {
         try {
           const compressedBlob = await compressImage(file);
           
           // Check size AFTER compression (Max 4.5MB safe limit for Supabase default)
           if (compressedBlob.size > 4.5 * 1024 * 1024) {
             toast.error('La imagen sigue siendo demasiado grande después de comprimir. Usa una imagen menor a 5MB.');
             return null;
           }

           // Create a new File from the Blob
           const newName = file.name.replace(/\.[^/.]+$/, "") + ".jpg";
           fileToUpload = new File([compressedBlob], newName, { type: 'image/jpeg' });
         } catch (compressErr: any) {
           console.warn("Compression failed:", compressErr);
           toast.error(compressErr.message || 'Error al procesar la imagen.');
           
           // If it failed because it's HEIC or explicit error, stop here.
           // If it failed for unknown reasons, we could try uploading original, 
           // BUT if original caused the crash before, better to stop.
           return null;
         }
      }

      const formData = new FormData();
      formData.append('file', fileToUpload);

      if (!projectId) {
          console.error("Missing projectId in environment variables");
          toast.error("Error de configuración: Falta Project ID");
          return null;
      }
      
      const uploadUrl = `${SERVER_URL}/upload`;
      console.log("Starting upload to:", uploadUrl);

      const response = await fetch(uploadUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
          // Do NOT set Content-Type for FormData, browser sets it with boundary
        },
        body: formData
      });

      if (!response.ok) {
        // Handle CORS or Network errors that return a status (e.g. 500, 403)
        const errorText = await response.text();
        let errorData = {};
        try {
            errorData = JSON.parse(errorText);
        } catch (e) {
            errorData = { error: errorText || `Server returned ${response.status}` };
        }
        console.error("Upload error details:", errorData);
        throw new Error((errorData as any).error || `Upload failed: ${response.status}`);
      }

      const data = await response.json();
      return data.url;
    } catch (err: any) {
      console.error("Upload process error:", err);
      // Detailed error for debugging "Failed to fetch"
      if (err.name === 'TypeError' && err.message === 'Failed to fetch') {
         console.error("Network error: Possible CORS issue, invalid URL, or server down.", {
             url: `${SERVER_URL}/upload`,
             projectId
         });
         toast.error('Error de conexión con el servidor. Verifica tu internet o contacta soporte.');
      } else if (err.message?.includes('exceeded the maximum allowed size')) {
        toast.error('La imagen es demasiado pesada para el servidor.');
      } else {
        toast.error(`Error al subir imagen: ${err.message}`);
      }
      return null;
    }
  };

  const fetchMedia = async () => {
    try {
      if (!projectId) return [];
      const response = await fetch(`${SERVER_URL}/media`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` }
      });
      if (!response.ok) return [];
      return await response.json();
    } catch (err) {
      console.error("Error fetching media:", err);
      return [];
    }
  };

  return {
    destinations,
    heroSlides,
    loading,
    error,
    saveDestinations,
    saveHero,
    saveReviews,
    reviews,
    whatsappNumber,
    heroSettings,
    saveSettings,
    uploadImage,
    fetchMedia,
    refresh: fetchAllData
  };
}
