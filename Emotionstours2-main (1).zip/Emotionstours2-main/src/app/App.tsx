import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CategoriesSection } from './components/CategoriesSection';
import { DestinationDetail } from './components/DestinationDetail';
import { ContactForm } from './components/ContactForm';
import { AboutSection } from './components/AboutSection';
import { ReviewsSection } from './components/ReviewsSection';
import { EmotionLogo } from './components/EmotionLogo';
import { AdminPanel } from './components/AdminPanel';
import { AdminLogin } from './components/AdminLogin';
import { Destination } from './data';
import { useDestinations } from './hooks/useDestinations';
import { Toaster } from 'sonner';
import { AnimatePresence, motion } from 'motion/react';

export default function App() {
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [bookingDestination, setBookingDestination] = useState<string>('');
  const [showAdmin, setShowAdmin] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  
  // Use our new dynamic data hook
  const { destinations, heroSlides, reviews, loading, saveDestinations, saveHero, saveReviews, saveSettings, whatsappNumber, heroSettings, uploadImage, fetchMedia } = useDestinations();

  // Handle browser back button navigation
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (selectedDestination) {
        setSelectedDestination(null);
      }
    };

    // Check for admin-panel query param
    const params = new URLSearchParams(window.location.search);
    if (params.has('admin-panel')) {
      setShowAdmin(true);
      // Clean URL to hide the trigger
      const newUrl = window.location.pathname;
      window.history.replaceState({}, '', newUrl);
    }

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [selectedDestination]);

  const handleNavigate = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else if (id === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleViewDestination = (dest: Destination) => {
    setSelectedDestination(dest);
    window.history.pushState({ modal: true, id: dest.id }, '', `#${dest.id}`);
  };

  const handleCloseDestination = () => {
    if (window.history.state?.modal) {
      window.history.back();
    } else {
      setSelectedDestination(null);
      if (window.location.hash) {
        window.history.replaceState(null, '', ' ');
      }
    }
  };

  const handleBook = (dest: Destination) => {
    setBookingDestination(dest.name);
    
    if (window.history.state?.modal) {
        window.history.back();
    } else {
        setSelectedDestination(null);
    }

    const contactSection = document.getElementById('contact');
    setTimeout(() => {
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 300);
  };

  return (
    <div className="bg-gradient-to-b from-sky-100 via-blue-50 to-white min-h-screen font-sans">
      <Toaster position="top-center" />
      <Navbar onNavigate={handleNavigate} />
      
      <main>
        <div id="home">
          <Hero 
            slides={heroSlides}
            destinations={destinations}
            settings={heroSettings}
            onExplore={() => handleNavigate('parks')} 
            onSearchSelect={handleViewDestination}
          />
        </div>

        <CategoriesSection 
          id="parks"
          title="Parques Temáticos" 
          category="Parks" 
          destinations={destinations} 
          onSelect={handleViewDestination} 
        />

        <CategoriesSection 
          id="tours"
          title="Tours Locales" 
          category="Tours" 
          destinations={destinations} 
          onSelect={handleViewDestination} 
        />

        <CategoriesSection 
          id="trips"
          title="Grandes Viajes" 
          category="Trips" 
          destinations={destinations} 
          onSelect={handleViewDestination} 
        />

        <AboutSection />

        <ReviewsSection reviews={reviews} />

        <ContactForm 
          key={bookingDestination} 
          initialDestination={bookingDestination} 
          destinations={destinations}
        />
      </main>

      <footer className="bg-slate-900 text-white py-12 border-t border-slate-800 relative">
        <div className="max-w-7xl mx-auto px-4 text-center flex flex-col items-center">
          <div className="mb-6 w-64 text-white">
            <EmotionLogo className="w-full h-auto brightness-0 invert opacity-90" />
          </div>
          <p className="text-slate-400 mb-8 max-w-md mx-auto">
            Hacemos de tus sueños una experiencia inolvidable. Viaja seguro, viaja con emoción.
          </p>

          <div className="flex gap-6 mb-10">
            <a 
                href="https://www.facebook.com/Emotionstours" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-[#1877F2] text-white p-3 rounded-full hover:scale-110 transition-transform flex items-center justify-center shadow-lg hover:shadow-[#1877F2]/40" 
                title="Facebook"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-facebook"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
            </a>
            
            <a 
                href="https://www.instagram.com/emotions.tours" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-gradient-to-tr from-[#FFD600] via-[#FF0100] to-[#D300C5] text-white p-3 rounded-full hover:scale-110 transition-transform flex items-center justify-center shadow-lg hover:shadow-[#D300C5]/40" 
                title="Instagram"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-instagram"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
            </a>
            
            <a 
                href="https://www.tiktok.com/@emotionstours" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-black text-white p-3 rounded-full hover:scale-110 transition-transform flex items-center justify-center shadow-lg hover:shadow-white/20 border border-white/10" 
                title="TikTok"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
            </a>
          </div>

          <div className="text-slate-600 text-sm flex flex-col items-center gap-4">
            <p>&copy; 2026 Emotion Tours. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>

      <AnimatePresence>
        {/* Floating WhatsApp Button */}
        <motion.a 
          key="whatsapp-button"
          href={`https://wa.me/52${whatsappNumber ? whatsappNumber.replace(/\s+/g, '') : '6647600861'}?text=${encodeURIComponent('Hola quiero información para viajar a....')}`}
          target="_blank"
          rel="noopener noreferrer"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          whileHover={{ scale: 1.1, rotate: 10 }}
          className="fixed bottom-6 right-6 z-[60] bg-green-500 text-white p-4 rounded-full shadow-2xl hover:bg-green-600 transition-all duration-300 flex items-center justify-center group"
          title="Contáctanos por WhatsApp"
        >
          {/* Using a reliable CDN for the WhatsApp logo */}
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
            alt="WhatsApp" 
            className="w-8 h-8 filter brightness-0 invert" 
          />
          <span className="absolute right-full mr-4 bg-white text-slate-800 px-4 py-2 rounded-lg shadow-xl text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none transform translate-x-2 group-hover:translate-x-0 hidden md:block">
            ¡Reserva aquí!
          </span>
        </motion.a>

        {selectedDestination && (
          <DestinationDetail 
            key="destination-detail"
            destination={selectedDestination} 
            onClose={handleCloseDestination} 
            onBook={handleBook}
          />
        )}
        
        {showAdmin && !isAdminAuthenticated && (
          <AdminLogin 
            onLogin={() => setIsAdminAuthenticated(true)} 
            onClose={() => setShowAdmin(false)} 
          />
        )}
        
        {showAdmin && isAdminAuthenticated && (
          <AdminPanel 
            key="admin-panel"
            destinations={destinations}
            heroSlides={heroSlides}
            reviews={reviews}
            whatsappNumber={whatsappNumber}
            heroSettings={heroSettings}
            onSave={saveDestinations}
            onSaveHero={saveHero}
            onSaveReviews={saveReviews}
            onSaveSettings={saveSettings}
            onUpload={uploadImage}
            onFetchMedia={fetchMedia}
            onClose={() => setShowAdmin(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
