
  # Emotions Tours

  This is a code bundle for Emotions Tours. The original project is available at https://www.figma.com/design/wOaqSLFQdCinIhQLDz9zC9/Emotions-Tours.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  